﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class InventoryRaycast : MonoBehaviour
{
    GraphicRaycaster m_Raycaster;
    PointerEventData m_PointerEventData;
    EventSystem m_EventSystem;

    List<RaycastResult> m_HitObjects;

    void Start()
    {
        m_Raycaster = GameObject.Find("UI").GetComponent<GraphicRaycaster>();
        m_EventSystem = GameObject.Find("UI").GetComponent<EventSystem>();

        m_PointerEventData = new PointerEventData(m_EventSystem);
        m_HitObjects = new List<RaycastResult>();
    }

    void Update()
    {
        // setup pointer event data object
        m_PointerEventData.position = Input.mousePosition;
        
        // clear list of hit object from the previous frame and init the raycast
        m_HitObjects.Clear();
        m_Raycaster.Raycast(m_PointerEventData, m_HitObjects);

        // now we have a list of hit objects in the list, make actions with got data here
        if (m_HitObjects.Count != 0)
        {
            if (Input.GetKeyDown(KeyCode.Mouse0))
            {
                foreach (RaycastResult result in m_HitObjects)
                {
                    Item item = result.gameObject.GetComponentInChildren<Item>();
                    if (item)
                        Debug.Log("LMB clicked - " +  item.Name);
                }
            }

            if (Input.GetKey(KeyCode.Mouse1))
            {
                foreach (RaycastResult result in m_HitObjects)
                {
                    GameObject obj = result.gameObject;                    
                    Item item = result.gameObject.GetComponentInChildren<Item>();
                    if (item)
                        Debug.Log("RMB pressed - " + item.Name);
                }
            }

        }
    }
}
