﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

[RequireComponent(typeof(GameManager))]
public class GUI_Manager : MonoBehaviour
{
    GameObject structure_GUI;
    GameObject unit_GUI;
    GameObject item_GUI;    

    GameObject itemActions_GUI;
    UPlayer player = null;
    Button takeButton;
    Button dropButton;

    GameObject inventory_GUI;

    public GameObject Get (string what)
    {
        GameObject guiObject = null;

        if (what == "structureInfo")
        {
            Activate("structureInfo");
            guiObject = structure_GUI;
        }

        if (what == "unitInfo")
        {
            Activate("unitInfo");
            guiObject = unit_GUI;
        }

        if (what == "itemInfo")
        {
            Activate("itemInfo");
            guiObject = item_GUI;
        }

        if (what == "itemActions")
        {
            Activate("itemActions");
            guiObject = itemActions_GUI;
        }

        if (what == "inventoryInfo")
        {
            Activate("inventoryInfo");
            guiObject = inventory_GUI;
        }

        return guiObject;
    }

    public bool IsActive (string what)
    {
        bool isActive = false;

        if (what == "structureInfo")
            isActive = structure_GUI.activeInHierarchy;

        if (what == "unitInfo")
            isActive = unit_GUI.activeInHierarchy;

        if (what == "itemInfo")
            isActive = item_GUI.activeInHierarchy;

        if (what == "itemActions")
            isActive = itemActions_GUI.activeInHierarchy;

        if (what == "inventoryInfo")
            isActive = inventory_GUI.activeInHierarchy;

        return isActive;
    }

    public void Activate (string what)
    {
        if (what == "structureInfo" && !structure_GUI.activeInHierarchy)
            structure_GUI.SetActive(true);

        if (what == "unitInfo" && !unit_GUI.activeInHierarchy)
            unit_GUI.SetActive(true);

        if (what == "itemInfo" && !item_GUI.activeInHierarchy)
            item_GUI.SetActive(true);

        if (what == "itemActions" && !itemActions_GUI.activeInHierarchy)
            itemActions_GUI.SetActive(true);

        if (what == "inventoryInfo" && !inventory_GUI.activeInHierarchy)
            inventory_GUI.SetActive(true);
    }

    public void Deactivate (string what)
    {
        if (what == "structureInfo" && structure_GUI.activeInHierarchy)
            structure_GUI.SetActive(false);

        if (what == "unitInfo" && unit_GUI.activeInHierarchy)
            unit_GUI.SetActive(false);

        if (what == "itemInfo" && item_GUI.activeInHierarchy)
            item_GUI.SetActive(false);

        if (what == "itemActions" && itemActions_GUI.activeInHierarchy)
            itemActions_GUI.SetActive(false);

        if (what == "inventoryInfo" && inventory_GUI.activeInHierarchy)
            inventory_GUI.SetActive(false);
    }

    void Init_ItemActions()
    {
        takeButton = GameObject.Find("IA - Take Button").GetComponent<Button>();
        dropButton = GameObject.Find("IA - Drop Button").GetComponent<Button>();
    }

    public void Enable(string what)
    {
        if (what == "itemActions - takeButton")
        {
            takeButton.interactable = true;
            takeButton.onClick.AddListener(player.OnTakeButtonClicked);
        }

        if (what == "itemActions - dropButton")
        {
            dropButton.interactable = true;
            dropButton.onClick.AddListener(player.OnDropButtonClicked);
        }
    }

    public void Disable (string what)
    {
        if (what == "itemActions - takeButton")
        {
            takeButton.interactable = false;
            takeButton.onClick.RemoveAllListeners();
        }

        if (what == "itemActions - dropButton")
        {
            dropButton.interactable = false;
            dropButton.onClick.RemoveAllListeners();
        }
    }

    void OnDropButtonClicked()
    {
        Debug.Log("in GUI_Manager:: onDropButtonClicked");
    }
    

    // Start is called before the first frame update
    void Awake()
    {
        structure_GUI = GameObject.Find("Structure");
        unit_GUI = GameObject.Find("Unit");
        item_GUI = GameObject.Find("Item");
        itemActions_GUI = GameObject.Find("Item Actions");
        inventory_GUI = GameObject.Find("Inventory");

        Init_ItemActions();

        structure_GUI.SetActive(false);
        unit_GUI.SetActive(false);
        item_GUI.SetActive(false);
        itemActions_GUI.SetActive(false);
        // inventory_GUI.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {        
        if (player == null)
        {
            Debug.Log("Player is NULL");
            player = GameObject.Find("Player").GetComponent<UPlayer>();

            return;
        }

        if (player)
        {
            if (Input.GetKeyDown(KeyCode.I))
                inventory_GUI.SetActive(!inventory_GUI.activeInHierarchy);
        }
    }
}
