﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

[RequireComponent(typeof(ItemEquippable))]
public class ItemEquippableGUI : MonoBehaviour
{
    ItemEquippable item;

    GUI_Manager gui;
    GameObject itemInfo;

    RawImage itemInfo_image;
    Text itemInfo_name;
    Text itemInfo_bonus;
    Text itemInfo_description;
    Text itemInfo_slot;
    Text itemInfo_durability;

    void GUI_Init()
    {
        item = GetComponent<ItemEquippable>();

        gui = GameObject.Find("Manager").GetComponent<GUI_Manager>();

        itemInfo = gui.Get("itemInfo");

        itemInfo_image = GameObject.Find("II - Texture").GetComponent<RawImage>();
        itemInfo_name = GameObject.Find("II - Name").GetComponent<Text>();
        itemInfo_bonus = GameObject.Find("II - Bonus").GetComponent<Text>();
        itemInfo_description = GameObject.Find("II - Description").GetComponent<Text>();
        itemInfo_slot = GameObject.Find("II - Slot").GetComponent<Text>();
        itemInfo_durability = GameObject.Find("II - Durability").GetComponent<Text>();
    }

    void GUI_Clear()
    {
        itemInfo_image.texture = null;
        itemInfo_name.text = "";
        itemInfo_bonus.text = "";
        itemInfo_description.text = "";
        itemInfo_slot.text = "";
        itemInfo_durability.text = "";
    }
    
    void GUI_Update()
    {
        if (!item)
            return;

        itemInfo_image.texture = item.Texture;
        itemInfo_name.text = item.Name;
        itemInfo_bonus.text = BonusAsText();
        itemInfo_description.text = item.Description;
        itemInfo_slot.text = SlotAsText();
        itemInfo_durability.text = DurabilityAsText();
    }

    string BonusAsText()
    {
        string bonusText = "";

        int HP_cur = item.Stats.CurrentHP;
        int HP_max = item.Stats.MaximumHP;
        int DMGP_min = item.Stats.Damage_Physical_Min;
        int DMGP_max = item.Stats.Damage_Physical_Max;
        int DMGM_min = item.Stats.Damage_Magical_Min;
        int DMGM_max = item.Stats.Damage_Magical_Max;
        int DEF = item.Stats.Defence;
        int RES = item.Stats.Resistance;

        if (HP_max > 0)
            bonusText += "Доб. " + HP_max + " ед. к макс. здоровью \n";

        if (DMGP_min > 0)
            bonusText += "Доб. " + DMGP_min + " ед. к мин. физ. урону \n";

        if (DMGP_max > 0)
            bonusText += "Доб. " + DMGP_max + " ед. к макс. физ. урону \n";

        if (DMGM_min > 0)
            bonusText += "Доб. " + DMGM_min + " ед. к мин. маг. урону \n";

        if (DMGM_max > 0)
            bonusText += "Доб. " + DMGM_max + " ед. к макс. маг. урону \n";

        if (DEF > 0)
            bonusText += "Доб. " + DEF + " ед. к защите \n";

        if (RES > 0)
            bonusText += "Доб. " + RES + " ед. к сопротивлению \n";

        return bonusText;
    }

    string SlotAsText()
    {
        string slotText;

        slotText = System.Enum.GetName(System.Type.GetType("Slot"), item.Slot);
        Debug.Log("Slot text is: " + slotText);

        return slotText;
    }

    string DurabilityAsText()
    {
        string durabilityText;

        int DUR_cur = item.CurDurability;
        int DUR_max = item.MaxDurability;

        durabilityText = DUR_cur + "\\" + DUR_max;

        return durabilityText;
    }

    void GUI_Description()
    {
        RaycastHit hit = new RaycastHit();
        Vector3 mousePosition = Input.mousePosition;
        if (Physics.Raycast(Camera.main.ScreenPointToRay(mousePosition), out hit))
        {
            Transform transform = hit.transform;

            ItemEquippable item_hit = transform.GetComponentInChildren<ItemEquippable>();
            if (item_hit)
            {
                Debug.Log("in ItemEquippableGUI::GUI_Description::item hit");

                if (item != item_hit)
                {
                    item = item_hit;

                    GUI_Update();
                }

                itemInfo.transform.position = mousePosition;
                itemInfo.SetActive(true);
            }
            else
                itemInfo.SetActive(false);
        }
        else
            itemInfo.SetActive(false);
    }

    // Start is called before the first frame update
    void Start()
    {
        GUI_Init();
        GUI_Update();
    }

    // Update is called once per frame
    void Update()
    {
        GUI_Description();    
    }
}