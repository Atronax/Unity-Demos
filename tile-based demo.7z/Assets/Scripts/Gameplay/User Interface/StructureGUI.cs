﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

[RequireComponent(typeof(Structure))]
public class StructureGUI : MonoBehaviour
{
    Structure structure;

    GUI_Manager gui;
    GameObject structureInfo;
    RawImage structureInfo_image;
    Text structureInfo_name_text;
    Text structureInfo_description_text;

    void Start()
    {        
        GUI_Init();
        GUI_Update();
    }

    public void GUI_Init()
    {
        structure = GetComponent<Structure>();

        gui = GameObject.Find("Manager").GetComponent<GUI_Manager>();

        structureInfo = gui.Get("structureInfo");

        structureInfo_image = GameObject.Find("SI - Sprite").GetComponent<RawImage>();
        structureInfo_name_text = GameObject.Find("SI - Name").GetComponent<Text>();
        structureInfo_description_text = GameObject.Find("SI - Description").GetComponent<Text>();
    }

    public void GUI_Update()
    {
        Debug.Log("in StructureGUI::GUI_Update:: name is " + structure.Name);

        structureInfo_image.texture = structure.Texture;
        structureInfo_name_text.text = structure.Name;
        structureInfo_description_text.text = structure.Description;
    }

    public void GUI_Clear()
    {
        structureInfo_image.texture = null;
        structureInfo_name_text.text = "";
        structureInfo_description_text.text = "";
    }

    public void GUI_Description()
    {      
        RaycastHit hit = new RaycastHit();
        if (Physics.Raycast(Camera.main.ScreenPointToRay(Input.mousePosition), out hit))
        {
            Transform transform = hit.transform;

            Debug.Log("in StructureGUI::GUI_Description::HIT");

            Structure structure_hit = transform.GetComponentInChildren<Structure>();
            if (structure_hit)
            {
                Debug.Log("in StructureGUI::GUI_Description::structure hit");

                if (structure != structure_hit)
                {
                    structure = structure_hit;
                    GUI_Update();
                }

                structureInfo.SetActive(true);
            }
            else
                structureInfo.SetActive(false);
        }
        else
            structureInfo.SetActive(false);
    }
    void Update()
    {
        GUI_Description();
    }
}
