﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

[RequireComponent(typeof(Unit))]
public class UnitGUI : MonoBehaviour
{
    GUI_Manager gui;
    Unit unit;

    // Basic info: avatar, name and description
    GameObject unitInfo;
    RawImage unitInfo_image;
    Text unitInfo_name_text;
    Text unitInfo_description_text;

    // Stats: icons and their storage, texts
    UnitGUITextures unitInfo_textures;
    RawImage unitInfo_currentHP_icon, unitInfo_maximumHP_icon;
    RawImage unitInfo_dmgPhysMin_icon, unitInfo_dmgPhysMax_icon;
    RawImage unitInfo_dmgMagMin_icon, unitInfo_dmgMagMax_icon;
    RawImage unitInfo_defence_icon, unitInfo_resistance_icon;

    Text unitInfo_currentHP_text, unitInfo_maximumHP_text;
    Text unitInfo_dmgPhysMin_text, unitInfo_dmgPhysMax_text;
    Text unitInfo_dmgMagMin_text, unitInfo_dmgMagMax_text;
    Text unitInfo_defence_text, unitInfo_resistance_text;

    // Health
    RectTransform currentHP_panel_rect;
    float currentHP_panel_width, currentHP_panel_height;

    void LoadBasicThings()
    {
        gui = GameObject.Find("Manager").GetComponent<GUI_Manager>();

        unitInfo = gui.Get("unitInfo");

        unitInfo_image = GameObject.Find("UI - Sprite").GetComponent<RawImage>();
        unitInfo_name_text = GameObject.Find("UI - Name").GetComponent<Text>();
        unitInfo_description_text = GameObject.Find("UI - Description").GetComponent<Text>();
    }

    void LoadStatsIcons()
    {
        unitInfo_textures = GameObject.Find("Textures").GetComponent<UnitGUITextures>();

        unitInfo_currentHP_icon = GameObject.Find("UI - Current HP Icon").GetComponent<RawImage>();
        unitInfo_maximumHP_icon = GameObject.Find("UI - Maximum HP Icon").GetComponent<RawImage>();
        unitInfo_dmgPhysMin_icon = GameObject.Find("UI - Dmg Physical Min Icon").GetComponent<RawImage>();
        unitInfo_dmgPhysMax_icon = GameObject.Find("UI - Dmg Physical Max Icon").GetComponent<RawImage>();
        unitInfo_dmgMagMin_icon = GameObject.Find("UI - Dmg Magical Min Icon").GetComponent<RawImage>();
        unitInfo_dmgMagMax_icon = GameObject.Find("UI - Dmg Magical Max Icon").GetComponent<RawImage>();
        unitInfo_defence_icon = GameObject.Find("UI - Defence Icon").GetComponent<RawImage>();
        unitInfo_resistance_icon = GameObject.Find("UI - Resistance Icon").GetComponent<RawImage>();

        unitInfo_currentHP_icon.texture = unitInfo_textures.currentHP_texture;
        unitInfo_maximumHP_icon.texture = unitInfo_textures.maximumHP_texture;
        unitInfo_dmgPhysMin_icon.texture = unitInfo_textures.dmgPhysMin_texture;
        unitInfo_dmgPhysMax_icon.texture = unitInfo_textures.dmgPhysMax_texture;
        unitInfo_dmgMagMin_icon.texture = unitInfo_textures.dmgMagMin_texture;
        unitInfo_dmgMagMax_icon.texture = unitInfo_textures.dmgMagMax_texture;
        unitInfo_defence_icon.texture = unitInfo_textures.defence_texture;
        unitInfo_resistance_icon.texture = unitInfo_textures.resistance_texture;
    }

    void LoadStatsTexts()
    {
        unitInfo_currentHP_text  = GameObject.Find("UI - Current HP Text").GetComponent<Text>();
        unitInfo_maximumHP_text  = GameObject.Find("UI - Maximum HP Text").GetComponent<Text>();
        unitInfo_dmgPhysMin_text = GameObject.Find("UI - Dmg Physical Min Text").GetComponent<Text>();
        unitInfo_dmgPhysMax_text = GameObject.Find("UI - Dmg Physical Max Text").GetComponent<Text>();
        unitInfo_dmgMagMin_text  = GameObject.Find("UI - Dmg Magical Min Text").GetComponent<Text>();
        unitInfo_dmgMagMax_text  = GameObject.Find("UI - Dmg Magical Max Text").GetComponent<Text>();
        unitInfo_defence_text    = GameObject.Find("UI - Defence Text").GetComponent<Text>();
        unitInfo_resistance_text = GameObject.Find("UI - Resistance Text").GetComponent<Text>();
    }

    void LoadHealthPanel()
    {
        currentHP_panel_rect = GameObject.Find("Current HP Panel").GetComponent<RectTransform>();
        currentHP_panel_width = currentHP_panel_rect.rect.width;
        currentHP_panel_height = currentHP_panel_rect.rect.height;
    }

    void Start()
    {
        GUI_Init();
        GUI_Update();
    }

    public void GUI_Init()
    {
        LoadBasicThings();
        LoadStatsIcons();
        LoadStatsTexts();
        LoadHealthPanel();
        GUI_Clear();       
    }

    public void GUI_Clear()
    {
        unitInfo_image.texture = null;
        unitInfo_name_text.text = "";
        unitInfo_description_text.text = "";

        unitInfo_currentHP_text.text = "";
        unitInfo_maximumHP_text.text = "";
        unitInfo_dmgPhysMin_text.text = "";
        unitInfo_dmgPhysMax_text.text = "";
        unitInfo_dmgMagMin_text.text = "";
        unitInfo_dmgMagMax_text.text = "";
        unitInfo_defence_text.text = "";
        unitInfo_resistance_text.text = "";
    }

    public void GUI_Update()
    {
        if (unit == null)
            return;

        unitInfo_image.texture = unit.Texture;
        unitInfo_name_text.text = unit.Name;
        unitInfo_description_text.text = unit.Description;

        unitInfo_currentHP_text.text  = unit.Stats.CurrentHP.ToString();
        unitInfo_maximumHP_text.text  = unit.Stats.MaximumHP.ToString();
        unitInfo_dmgPhysMin_text.text = unit.Stats.Damage_Physical_Min.ToString();
        unitInfo_dmgPhysMax_text.text = unit.Stats.Damage_Physical_Max.ToString();
        unitInfo_dmgMagMin_text.text  = unit.Stats.Damage_Magical_Min.ToString();
        unitInfo_dmgMagMax_text.text  = unit.Stats.Damage_Magical_Max.ToString();
        unitInfo_defence_text.text    = unit.Stats.Defence.ToString();
        unitInfo_resistance_text.text = unit.Stats.Resistance.ToString();

        float currentHP_panel_newwidth = (currentHP_panel_width / unit.Stats.MaximumHP) * unit.Stats.CurrentHP;
        Vector2 currentHP_panel_newsize = new Vector2(currentHP_panel_newwidth, currentHP_panel_height);
        currentHP_panel_rect.sizeDelta = currentHP_panel_newsize;
    }

    public void GUI_Description()
    {
        RaycastHit hit = new RaycastHit();
        if (Physics.Raycast(Camera.main.ScreenPointToRay(Input.mousePosition), out hit))
        {
            Transform transform = hit.transform;

            Unit unit_hit = transform.GetComponentInChildren<Unit>();
            if (unit_hit)
            {
                if (unit != unit_hit)
                {
                    unit = unit_hit;
                    GUI_Update();
                }

                unitInfo.SetActive(true);
            }
            else
                unitInfo.SetActive(false);
        }    
        else
            unitInfo.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
        GUI_Description();
    }
}
