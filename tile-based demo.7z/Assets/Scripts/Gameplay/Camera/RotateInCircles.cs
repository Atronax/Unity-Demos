﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RotateInCircles : MonoBehaviour
{
    [SerializeField] int radius;
    [SerializeField] float angleStep;

    Vector3 origin;
    float angle;
    float time;

    float time_to_shift;
    bool sign;

    // Start is called before the first frame update
    void Start()
    {
        origin = transform.position;
    }

    // Update is called once per frame
    void Update()
    {
        time += Time.deltaTime;
        time_to_shift += time;

        if (time_to_shift > 10.0f)
        {
            sign = !sign;
            time_to_shift = 0.0f;
        }
         
        if (0.025f - time < 0.0f)
        {
            angle += angleStep;
            Debug.Log("Angle: " + angle);
                        
            Vector3 position = transform.position;
            if (sign)
            {
                position.x = origin.x + (radius / 2) * Mathf.Cos(angle);
                position.y = origin.y + (radius / 2) * Mathf.Sin(angle);
            }
            else
            {
                position.x = origin.x + radius * Mathf.Cos(angle);
                position.y = origin.y + radius * Mathf.Sin(angle);
            }
            
            Debug.Log("Position: " + position.x + "-" + position.y);

            Quaternion rotation = Quaternion.identity;

            transform.SetPositionAndRotation(position, rotation);

            time = 0.0f;
        }        
    }
}
