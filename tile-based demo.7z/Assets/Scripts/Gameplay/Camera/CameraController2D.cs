﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraController2D : MonoBehaviour
{
    [SerializeField] float speed = 3.0f;

    Vector3 Direction()
    {
        Vector3 direction = new Vector3();
        
        if (Input.GetKey(KeyCode.W)) { direction += Vector3.up; }
        if (Input.GetKey(KeyCode.S)) { direction += Vector3.down; }
        if (Input.GetKey(KeyCode.A)) { direction += Vector3.left; }
        if (Input.GetKey(KeyCode.D)) { direction += Vector3.right; }

        return direction;
    }

    void Update()
    {
        Vector3 mouseMovement = new Vector3(Input.GetAxis("Mouse X"), Input.GetAxis("Mouse Y"), 0).normalized;

        

        Vector3 move;
        if (Input.GetMouseButton(0))
        {
            // Cursor.lockState = CursorLockMode.Locked;
            move = mouseMovement;
        }
        else
        {
            // Cursor.visible = true;
            // Cursor.lockState = CursorLockMode.None;

            move = Direction();
        }

        speed += Input.mouseScrollDelta.y * 0.2f;
        if (speed > 5.0f) speed = 5.0f;
        if (speed < 3.0f) speed = 3.0f;
        move *= Mathf.Pow(2.0f, speed);

        Vector3 translation = move * Time.deltaTime;

        // Speed up movement when shift key held
        if (Input.GetKey(KeyCode.LeftShift))        
            translation *= 2.0f;

        Camera.main.transform.position += translation;
    }
}
