﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum Slot
{
    HEAD   = 0,
    TORSO  = 1,
    LEGS   = 2,
    BOOTS  = 3,
    HAND_R = 4,
    HAND_L = 5,
    AMULET = 6,
    RING_R = 7,
    RING_L = 8
}

[RequireComponent(typeof(UPlayer))]
[RequireComponent(typeof(Stats))]
public class Inventory_Equipment : MonoBehaviour
{
    // Player stats
    Stats player_stats;

    // Slots for equipment
    Item head;
    Item torso;
    Item legs;
    Item boots;
    Item hand_r, hand_l;
    Item amulet;
    Item ring_r, ring_l;

    public void Equip(Item item)
    {
    }

    public void Unequip(Item item)
    {
    }

    /* public void Equip()
    {
        // unequip();
        // if there is an item already equipped to this slot, unequip it
        // then put on this item based on slot
    }

    public void Unequip()
    {
        // if (player.Inventory.IsEquipped(slot))
        // player.Stats -= player.Inventory.ItemAtSlot(slot).Stats; --> убрать бонус предмета
        // player.Inventory.Putoff(item); --> снять шмотку и поместить ее в мешок.
    } */

    void Start()
    {
        player_stats = GameObject.Find("Player").GetComponent<Stats>();
    }

    public void Update()
    {

    }
}
