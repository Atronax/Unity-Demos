﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class Inventory_Bag : MonoBehaviour
{
    [SerializeField] const int bag_capacity = 24;
    [SerializeField] List<Item> items = new List<Item>(bag_capacity);
    [SerializeField] List<GameObject> slots = new List<GameObject>(bag_capacity);

    // GUI stuff
    GUI_Manager gui;
    GameObject itemInfo;
    Item item_current;

    GraphicRaycaster raycaster;
    PointerEventData pointerEventData;
    EventSystem eventSystem;
    List<RaycastResult> hit;

    int frame = 0;

    bool needsUpdate = false;

    void Start()
    {
        InitGUI();
        InitItemsList();
        InitSlotsList();
    }

    void InitGUI()
    {
        gui = GameObject.Find("Manager").GetComponent<GUI_Manager>();
        itemInfo = gui.Get("itemInfo");

        raycaster = GameObject.Find("UI").GetComponent<GraphicRaycaster>();
        eventSystem = GameObject.Find("UI").GetComponent<EventSystem>();
        pointerEventData = new PointerEventData(eventSystem);
        hit = new List<RaycastResult>();
    }

    

    void InitItemsList()
    {
        for (int i = 0; i < bag_capacity; ++i)
            items.Insert(i, null);
    }

    void InitSlotsList()
    {
        for (int i = 0; i < bag_capacity; ++i)
        {
            string currentBagSlot = "Bag - " + (i + 1);

            GameObject slotObj = GameObject.Find(currentBagSlot);
            slots.Insert(i, GameObject.Find(currentBagSlot));            
        }
    }

    int NextFreeSlot()
    {
        int nextFreeSlot = 0;
        for (int i = 0; i < bag_capacity; ++i)
        {
            if (items[i] == null)
            {
                nextFreeSlot = i;
                return nextFreeSlot;
            }
        }

        return -1;
    }

    public void Take(Item item)
    {
        Add(item);
    }

    public void Drop(Item item)
    {
        Remove(item);
    }

    // various addition and removal functions

    void Add(Item item)
    {
        int index = NextFreeSlot();

        items.RemoveAt(index);
        items.Insert(index, item);

        Transform slot = slots[index].transform;
        Instantiate<Item>(item, slot.position, slot.rotation, slot);

        needsUpdate = true;
    }

    void Remove(Item item)
    {
        int index = items.IndexOf(item);

        items.RemoveAt(index);

        Destroy(item);

        needsUpdate = true;
    }

    void RemoveAll()
    {
        for (int i = 0; i < bag_capacity; ++i)
            items[i] = null;

        needsUpdate = true;
    }

    void Update()
    {
        ++frame;

        hit.Clear();

        pointerEventData.position = Input.mousePosition;
        raycaster.Raycast(pointerEventData, hit);

        // hits an object and all its children whose rects are situated there
        if (hit.Count == 2)
        {
            hit.RemoveAt(1); // Remove Inventory UI, leave only Bag Slots

            // Debug.Log("HIT " + hit.Count + " objects");

            if (Input.GetMouseButtonDown(0))
            {
                foreach (RaycastResult result in hit)
                {
                    Debug.Log(result.gameObject.name);

                    Item item = result.gameObject.GetComponentInChildren<Item>();
                    if (item)
                    {
                        Debug.Log("LMB clicked - " + frame + " - " + item.Name);
                        return;
                    }
                }
            }

            if (Input.GetMouseButton(1))
            {
                foreach (RaycastResult result in hit)
                {
                    Item item = result.gameObject.GetComponentInChildren<Item>();
                    if (item)
                        Debug.Log("RMB pressed - " + item.Name);
                }
            }

        }


        GUI_ShowItemInformation();
        GUI_ShowThumbnails();
    }

    bool ParentContainsPoint(float x, float y)
    {
        RectTransform rectangle = GetComponent<RectTransform>();

        float x1 = rectangle.position.x;
        float y1 = rectangle.position.y;
        float x2 = x1 + rectangle.rect.width;        
        float y2 = y1 - rectangle.rect.height;

        // Debug.Log("PCP: " + x1 + " * " + y1 + " // " + x2 + " * " + y2);

        bool parentContainsThisPoint = false;
        if (x >= x1 && x <= x2 && y >= y2 && y <= y1)
            parentContainsThisPoint = true;

        return parentContainsThisPoint;
    }

    void GUI_ShowItemInformation()
    {
        if (!gui.IsActive("inventoryInfo"))
            return;

    }

    void GUI_UpdateItemInformation()
    {
        
    }

    void GUI_ShowThumbnails()
    {
        if (needsUpdate)
        {
            for (int i = 0; i < bag_capacity; ++i)
            {
                if (items[i])
                {
                    RawImage thumbnail = slots[i].GetComponent<RawImage>();
                    thumbnail.texture = items[i].Texture;
                }
            }
        }
    }
}
