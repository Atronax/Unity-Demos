﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Position
{
    public int x;
    public int y;

    public Position (int _x, int _y)
    {
        x = _x;
        y = _y;
    }
}

public class TileInfo
{
    public TileInfo(GameObject _tile, Position _position)
    {
        tile = _tile;
        position = _position;
    }

    public bool IsReachable()
    {
        if (tile == null)
            return false;
        else
            return !tile.GetComponent<Tile>().Solid;
    }

    public bool HasNoStructures()
    {
        if (structure == null)
            return true;
        else
            return false;
    }

    public bool HasNoUnits()
    {
        if (unit == null)
            return true;
        else
            return false;
    }

    public bool HasNoItems()
    {
        if (item == null)
            return true;
        else
            return false;
    }

    public GameObject tile = null;
    public GameObject structure = null;
    public GameObject unit = null;
    public GameObject item = null;

    public Position position;
}

public enum Direction
{
    UP = 0,
    DOWN = 1,
    LEFT = 2,
    RIGHT = 3
}

public class GameManager : MonoBehaviour
{
    // размеры карты и список тайлов
    [SerializeField] int width;
    [SerializeField] int height;
    List<TileInfo> tiles = new List<TileInfo>();

    GameObject player;

    public int Width
    {
        get { return width; }
        set { if (width >= 0 && width < 32) width = value; else width = 0; }
    }

    public int Height
    {
        get { return height; }
        set { if (height >= 0 && height < 32) height = value; else height = 0; }
    }

    public GameObject Player
    {
        get { return player; }
    }

    public List<TileInfo> Tiles
    {
        get { return tiles; }
    }

    public void Clear()
    {
        foreach (TileInfo ti in tiles)
        {
            Destroy(ti.tile);
            Destroy(ti.structure);
            Destroy(ti.unit);
            Destroy(ti.item);
        }

        tiles.Clear();
    }

    public int Size()
    {
        return width * height;
    }

    public TileInfo TileInfoForTile(Tile tile)
    {
        TileInfo result = null;

        for (int i = 0; i < tiles.Count; ++i)
        {
            if (tiles[i].tile.transform == tile.transform)
                result = tiles[i]; 
        }

        return result;
    }

    public TileInfo TileInfoForIndex(int index)
    {
        TileInfo result = null;

        if (index >= 0 && index < tiles.Count)
            result = tiles[index];
       
        return result;
    }

    public TileInfo TileInfoForCoords(int x, int y)
    {
        Debug.Log("GameManager::TileInfoForCoords::" + x + "-" + y);

        TileInfo currentTI = null;

        for (int i = 0; i < tiles.Count; ++i)
        {
            currentTI = tiles[i];
            if (currentTI.position.x == x && currentTI.position.y == y)
                return currentTI;
        }

        return currentTI;
    }

    // Start is called before the first frame update
    void Awake()
    {
        player = GameObject.Find("Player");
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
