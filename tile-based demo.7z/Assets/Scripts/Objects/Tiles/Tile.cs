﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// Перечисление возможных типов поверхности тайла.
public enum SurfaceType
{
    NONE = 0,
    GRASS = 1,
    SAND = 2,
    MOUNTAIN = 3
};

[RequireComponent(typeof(SpriteRenderer))]
public class Tile : MonoBehaviour
{
    // Описание строительного кирпичика для карт. Что есть тайл? Прежде всего, это его тип.
    // Типом определяется его внешний вид и характеристики, например проходимость и цена перемещения.
    // Также сюда можна внедрять дополнительные параметры, переменные и функции для расширения функционала тайлов.

    public SurfaceType surfaceType;

    TileTextures textures;
    SpriteRenderer render;

    [SerializeField] bool isSolid = false;

    float passed_time = 0.0f;

    void Awake()
    {
        // Загрузим класс данных, в которых хранятся текстуры для дальнейшего применения.
        textures = GameObject.Find("Textures").GetComponent<TileTextures>();

        // Для формирования и изменения внешнего вида объекта нам потребуется взаимодействовать с
        // компонентом типа SpriteRenderer, поэтому прицепим его к нашей переменной render.
        render = transform.GetComponent<SpriteRenderer>();
    }

    // Start is called before the first frame update
    void Start()
    {    
        // Устанавливаем базовый тип для всех тайлов. В данном случае это тип SurfaceType.None.
        // В качестве текстуры он использует картинку с надписью TILE в центре и рамкой черного цвета.
        // Это непроходимый тайл, поэтому его переменная isSolid равна true.
        // setSurfaceType(SurfaceType.NONE);
    }

    // Функция обновления вызывается один раз на кадр. Все изменения, 
    // касающиеся данного объекта, следует проводить в этой функции.
    void Update()
    {
        // updateType();
    }

    void updateType()
    {
        // Time.deltaTime указывает на время, которое прошло с момента предыдущего тайла.
        // Следовательно, в переменной passed_time мы накапливаем пройденное время до тех пор,
        // пока оно не станет равным одной секунде. Затем мы случайным образом формируем число от 1 до 3
        // включительно и с помощью переменной setSurfaceType заменяем тип текущего тайла.
        // Затем обнуляем пройденное время и запускаем карусель сначала.

        passed_time += Time.deltaTime;
 
        if (1.0f - passed_time < 0.0f)
        {
            int value = Random.Range(1, 5);
            if (value == 1)
                setSurfaceType(SurfaceType.NONE);
            else if (value == 2)
                setSurfaceType(SurfaceType.GRASS);
            else if (value == 3)
                setSurfaceType(SurfaceType.SAND);
            else if (value == 4)
                setSurfaceType(SurfaceType.MOUNTAIN);

            passed_time = 0.0f;
        }
    }
    
    void setTexture(Texture2D tex)
    {
        if (render.sprite == null)
            Debug.Log("in setTexture: there is no render.sprite object");

        Rect rect = render.sprite.rect;
        Vector2 pivot = new Vector2 (0.5f, 0.5f);
        int pixelsPerUnit = 64;

        render.sprite = Sprite.Create(tex, rect, pivot, pixelsPerUnit);

        // Debug.Log("Is Solid: " + isSolid);
        if (isSolid)
            render.color = new Color(1.0f, 0.0f, 0.0f, 0.75f);
        else
            render.color = Color.white;
    }

    public bool Solid
    {
        get { return isSolid; }
    }

    public SurfaceType getSurfaceType() 
    { 
        return surfaceType; 
    }
        
    public void setSurfaceType(SurfaceType type)
    {
        if (surfaceType == type)
            return;
        
        surfaceType = type;
        switch (surfaceType)
        {
            case SurfaceType.NONE:
                isSolid = true;
                setTexture(textures.noneTexture);
                break;

            case SurfaceType.GRASS:
                isSolid = false;
                setTexture(textures.grassTexture);
                break;

            case SurfaceType.SAND:
                isSolid = false;
                setTexture(textures.sandTexture);
                break;

            case SurfaceType.MOUNTAIN:
                isSolid = true;
                setTexture(textures.mountainTexture);
                break;

            default:
                break;
        }
    }   
}