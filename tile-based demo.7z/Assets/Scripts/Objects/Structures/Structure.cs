﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum StructureType
{
    FOOD_STATION = 0,
    DOOR = 1,
    TREE = 2,
    BARREL = 3,
    JAR = 4,
    CHEST = 5,
    BOULDER = 6
}
public abstract class Structure : MonoBehaviour
{
    [SerializeField] Texture2D texture;
    [SerializeField] StructureType type;
    [SerializeField] string _name;
    [SerializeField] string description;

    public Texture2D Texture
    {
        get { return texture; }
        set { texture = value; }
    }

    public StructureType Type
    {
        get { return type; }
        set { type = value; }
    }

    public string Name
    {
        get { return _name; }
        set { _name = value; }
    }

    public string Description
    {
        get { return description; }
        set { description = value; }
    }

    public abstract void Use();
}
