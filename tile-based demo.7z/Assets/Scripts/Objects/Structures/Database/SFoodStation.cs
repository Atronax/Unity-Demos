﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(SpriteRenderer))]
public class SFoodStation : Structure, IUpgradable, IDestructible
{
    // Inventory inventory; // предметы в инвентаре игрока, если нужно взаимодействие с инвентарем
    UPlayer player;         //       характеристики игрока, если нужно взаимодействие со статами игрока

    // уровень:
    // 1 - простой, восстанавливает здоровье 
    // 2 - стандартный, восстанавливает здоровье, повышает максимальный запас
    // 3 - качественный, восстанавливает здоровье, повышает максимальный запас и характеристики
    int m_level = 1;
    int m_requiredGold = 100;

    // эффективность:
    // - чем ниже эффективность, тем меньше восстанавливает ХП, и наоборот;
    // - при развитии добавляет постэффекты с бонусом, который зависит от этого параметра.
    float m_effectivity = 1.0f; 

    // состояние:
    // - максимальный запас крепости определяет, сколько пинков ногой котел может пережить до полной поломки
    // - текущий запас крепости определяет текущее состояние котла
    int m_currentDurability = 100;
    int m_maximumDurability = 100;

    
    public int Level
    {
        get { return m_level; }
    }

    public int RequiredGold
    {
        get { return m_requiredGold; }
        set { m_requiredGold = value; }
    }

    public int CurDurability
    {
        get { return m_currentDurability; }        
    }

    public int MaxDurability
    {
        get { return m_maximumDurability; }
    }    

    public void Break(int pts)
    {
        m_currentDurability -= pts;
        if (m_currentDurability < 0)
            m_currentDurability = 0;

        BreakEffect();
    }

    public void Repair(int pts)
    {
        m_currentDurability += pts;
        if (m_currentDurability > m_maximumDurability)
            m_currentDurability = m_maximumDurability;

        RepairEffect();
    }

    public void BreakEffect()
    {
        if (m_currentDurability >= 200)
            m_effectivity = 2.0f;
        else if (m_currentDurability >= 100)
            m_effectivity = 1.0f;
        else if (m_currentDurability >= 50)
            m_effectivity = 0.5f;
        else if (m_currentDurability >= 25)
            m_effectivity = 0.25f;
        else if (m_currentDurability >= 0)
            m_effectivity = 0.0f;
    }
   
    public void RepairEffect()
    {
        if (m_currentDurability >= 0)
            m_effectivity = 0.0f;
        else if (m_currentDurability >= 25)
            m_effectivity = 0.25f;
        else if (m_currentDurability >= 50)
            m_effectivity = 0.5f;
        else if (m_currentDurability >= 100)
            m_effectivity = 1.0f;
        else if (m_currentDurability >= 200)
            m_effectivity = 2.0f;
    }    

    public void Upgrade()
    {
        // если у игрока есть требуемое количество золота, 
        // он может улучшить котел, при этом меняется: 
        // - внешний вид котла, 
        // - его название и описание, 
        // - эффект от применения функции use

        switch (Level)
        {
            case 1:
                m_level = 2;
                break;

            case 2:
                m_level = 3;
                break;

            case 3:
                Debug.Log("Больше нет возможности для улучшения.");
                break;
        }
    }

    public override void Use()
    {
        // когда игрок применяет котел, он получает различные преимущества в зависимости от его уровня
        // 1 - простой, восстанавливает здоровье 
        // 2 - стандартный, восстанавливает здоровье, повышает максимальный запас
        // 3 - качественный, восстанавливает здоровье, повышает максимальный запас и характеристики

        Unit unit = player.GetComponent<Unit>();
        UnitGUI unit_GUI = player.GetComponent<UnitGUI>();

        switch (Level)
        {
            case 1:
                unit.Stats.CurrentHP = unit.Stats.MaximumHP;
                unit_GUI.GUI_Update();
                break;

            case 2:
                break;

            case 3:
                break;
        }        
    }

    void Start()
    {        
        // player_inventory = GameObject.Find("Player").GetComponent<Inventory>();

        /*
        int player_gold = player_inventory.gold();
        if (player_gold > RequiredGold)
        {
            player_inventory.setGold(player_gold - RequiredGold);
            Upgrade();
        }
        */
    }

    void LookForPlayer()
    {
        if (!player)
        {
            GameObject playerGO = GameObject.Find("Player");
            if (playerGO)
                player = playerGO.GetComponent<UPlayer>();
            else
                Debug.Log("There is no player on the scene");
        }
    }

    // Update is called once per frame
    void Update()
    {
        LookForPlayer();
    }
}
