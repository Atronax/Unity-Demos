﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ItemConsumable : Item, IConsumable
{
    public int consume_count 
    {
        get { return consume_count; }
        set { consume_count = value; } 
    }

    public void Consume()
    {
        --consume_count;
        
        // do some stuff with players stats etc etc etc

        if (consume_count == 0)
            Destroy(gameObject);
    }
}
