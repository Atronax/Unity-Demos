﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum IEWeaponID
{
    Knife = 0,
    KnifeOfRagnarek = 1,
    Sword = 2,
    Staff = 3
}

public class IEWeapon : ItemEquippable
{
    ItemTextures textures;
    ItemPrefabs prefabs;

    [SerializeField] IEWeaponID weaponID;       
    

    void Awake()
    {        
        Init();
    }

    void Init()
    {
        textures = GameObject.Find("Textures").GetComponent<ItemTextures>();
        prefabs = GameObject.Find("Prefabs").GetComponent<ItemPrefabs>();

        Slot = Slot.HAND_R;

        switch (weaponID)
        {
            case IEWeaponID.Knife:
                Name = "Нож бандюка";
                Description = "Похищенный из тайника банды четырех.";
                Texture = textures.knifeTexture;
                Stats = Stats.Create(0, 0, 2, 4, 0, 0, 0, 0);
                CurDurability = MaxDurability = 10;
                Prefab = prefabs.knife;
                break;

            case IEWeaponID.KnifeOfRagnarek:
                Name = "Кинжал Рагнарека";
                Description = "Способен поразить мифических существ.";
                Texture = textures.knifeRagnarekTexture;
                Stats = Stats.Create(0, 0, 8, 10, 2, 3, 0, 5);
                CurDurability = MaxDurability = 20;
                Prefab = prefabs.knifeOfRagnarek;
                break;


            case IEWeaponID.Sword:
                break;

            case IEWeaponID.Staff:
                break;
        }
    }
}
