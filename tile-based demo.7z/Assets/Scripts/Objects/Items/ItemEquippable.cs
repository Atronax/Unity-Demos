﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ItemEquippable : Item, IEquippable, IDestructible
{
    Slot m_slot;
    Stats m_stats;

    int m_curDurability;
    int m_maxDurability;

    public Slot Slot
    {
        get { return m_slot; }
        set { m_slot = value; }
    }

    public Stats Stats
    {
        get { return m_stats; }
        set { m_stats = value; }
    }

    public int CurDurability
    {
        get { return m_curDurability; }
        set 
        {
            m_curDurability = value;

            if (m_curDurability > m_maxDurability)
                m_curDurability = m_maxDurability;

            if (m_curDurability < 0)
                m_curDurability = 0;
        }
    }

    public int MaxDurability
    {
        get { return m_maxDurability; }
        set
        {
            m_maxDurability = value;

            if (m_maxDurability < 0)
                m_maxDurability = 0;
        }
    }

    public void Break(int pts)
    {
        m_curDurability -= pts;

        BreakEffect();
    }

    public void Repair(int pts)
    {
        m_curDurability += pts;

        RepairEffect();
    }

    public void BreakEffect()
    {
        // override by items
    }
    
    public void RepairEffect()
    {
        // override by items
    }

    public void Equip()
    {
        // unequip();
        // if there is an item already equipped to this slot, unequip it
        // then put on this item based on slot
    }    

    public void Unequip()
    {
        // if (player.Inventory.IsEquipped(slot))
        // player.Stats -= player.Inventory.ItemAtSlot(slot).Stats; --> убрать бонус предмета
        // player.Inventory.Putoff(item); --> снять шмотку и поместить ее в мешок.
    }
}
