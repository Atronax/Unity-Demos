﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ItemReagent : Item, IStackable
{
    public int count_inStack
    {
        get { return count_inStack; }
        set
        {
            count_inStack = value;
            if (count_inStack < 0)
                count_inStack = 0;
        }
    }

    public void AddToStack()
    {
        ++count_inStack;
    }

    public void RemoveFromStack()
    {
        --count_inStack;
    }
}
