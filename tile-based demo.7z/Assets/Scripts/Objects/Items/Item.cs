﻿using UnityEngine;

public class Item : MonoBehaviour, IDescription
{
    string m_name;
    string m_description;
    Texture2D m_texture;
    GameObject m_prefab;

    public string Name
    {
        get { return m_name; }
        set { m_name = value; }
    }

    public string Description
    {
        get { return m_description; }
        set { m_description = value; }
    }

    public Texture2D Texture
    {
        get { return m_texture; }
        set { m_texture = value; }
    }

    public GameObject Prefab
    {
        get { return m_prefab; }
        set { m_prefab = value; }
    }

    public void GUI_Description()
    {
        // ясно что 
    }
}
