﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Stats : MonoBehaviour
{
    [SerializeField] int hp_cur;
    [SerializeField] int hp_max;

    [SerializeField] int def;
    [SerializeField] int res;

    [SerializeField] int dmg_min_phy;
    [SerializeField] int dmg_max_phy;

    [SerializeField] int dmg_min_mag;
    [SerializeField] int dmg_max_mag;

    // maximum values for parameters
    const int DEF_MAX = 100;
    const int RES_MAX = 100;
    const int DMG_PHY_MAX = 150;
    const int DMG_MAG_MAX = 150;

    public static Stats Create (int currentHP, int maximumHP, 
                                int damagePMin, int damagePMax, 
                                int damageMMin, int damageMMax, 
                                int defence, int resistance)
    {
        Stats stats = new Stats();

        stats.hp_cur = currentHP;
        stats.hp_max = maximumHP;

        stats.dmg_min_phy = damagePMin;
        stats.dmg_max_phy = damagePMax;

        stats.dmg_min_mag = damageMMin;
        stats.dmg_max_mag = damageMMax;      

        stats.def = defence;
        stats.res = resistance;

        return stats;
    }

    public int CurrentHP
    {
        get 
        {
            int val = hp_cur;
            if (val > hp_max)
                val = hp_max;
            if (val < 0)
                val = 0;

            return val; 
        }

        set { hp_cur = value; }
    }

    public int MaximumHP
    {
        get 
        {
            int val = hp_max;
            if (val < 0)
                val = 0;

            return val; 
        }

        set { hp_max = value; }
    }

    public int Defence
    {
        get 
        {
            int val = def;
            if (val < 0)
                val = 0;
            if (val > DEF_MAX)
                val = DEF_MAX;

            return val; 
        }

        set { def = value; }
    }

    public int Resistance
    {
        get 
        {
            int val = res;
            if (val < 0)
                val = 0;
            if (val > RES_MAX)
                val = RES_MAX;

            return val; 
        }

        set { res = value; }
    }

    public int Damage_Physical_Min
    {
        get 
        {
            int val = dmg_min_phy;
            if (val < 0)
                val = 0;
            if (val > DMG_PHY_MAX)
                val = DMG_PHY_MAX;

            return val; 
        }

        set { dmg_min_phy = value; }
    }

    public int Damage_Physical_Max
    {
        get 
        {
            int val = dmg_max_phy;
            if (val < 0)
                val = 0;
            if (val > DMG_PHY_MAX)
                val = DMG_PHY_MAX;

            return val; 
        }

        set { dmg_max_phy = value; }
    }

    public int Damage_Magical_Min
    {
        get 
        {
            int val = dmg_min_mag;
            if (val < 0)
                val = 0;
            if (val > DMG_MAG_MAX)
                val = DMG_MAG_MAX;

            return val; 
        }

        set { dmg_min_mag = value; }
    }

    public int Damage_Magical_Max
    {
        get 
        {
            int val = dmg_max_mag;
            if (val < 0)
                val = 0;
            if (val > DMG_MAG_MAX)
                val = DMG_MAG_MAX;

            return val; 
        }

        set { dmg_max_mag = value; }
    }

    public void TakeDamage(int damage, AttackType attackType)
    {
        int actualDamage = 0;
        switch (attackType)
        {
            case AttackType.PHYSICAL:
                actualDamage = damage - (def * damage) / 100;
                break;

            case AttackType.MAGICAL:
                actualDamage = damage - (res * damage) / 100;
                break;
        }

        CurrentHP -= actualDamage;
        // changes on GUI and other stuff
        if (CurrentHP == 0)
            Debug.Log("No more HP"); // nuzhe, do smth.. tyk tyk
        
    }
}
