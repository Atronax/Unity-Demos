﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum AttackType
{
    PHYSICAL = 0,
    MAGICAL = 1
}

public class UPlayer : Unit
{
    GameManager manager;
    GUI_Manager gui;

    Inventory_Bag bag;
    Inventory_Equipment equipment;

    TileInfo previousTI;
    TileInfo currentTI;

    Position spawnPosition;
    Position currentPosition;

    bool isFighting = false;
    
    public override void Attack (Unit other, AttackType attackType)
    {
        if (Stats.CurrentHP <= 0)
            return;

        Stats myStats = base.Stats;
        Stats otherStats = other.GetComponent<Stats>();

        int damage = 0;
        string damage_type = "";
        if (attackType == AttackType.PHYSICAL)
        {
            damage = Random.Range(myStats.Damage_Physical_Min, myStats.Damage_Physical_Max + 1);
            damage_type = "physical";
        }

        if (attackType == AttackType.MAGICAL)
        {
            damage = Random.Range(myStats.Damage_Magical_Min, myStats.Damage_Magical_Max + 1);
            damage_type = "magical";
        }

        if (damage_type == "physical")
            Debug.Log("Игрок атакует врага и наносит ему " + damage + " урона оружием.");
        else if (damage_type == "magical")
            Debug.Log("Игрок атакует врага и наносит ему " + damage + " урона заклинанием.");

        otherStats.TakeDamage(damage, attackType);
    }

    public AttackType SelectAttackType()
    {
        AttackType AT = AttackType.PHYSICAL;

        int value = Random.Range(0, 2);
        if (value == 1)
            AT = AttackType.MAGICAL;
         
        return AT;
    }

    public IEnumerator Fight (Unit other)
    {
        // While there still no winner
        // Select attack type for first attacker (with higher initiative value)
        // Attack other with selected attack type
        // Update GUI for second attacker
        // Select attack type for second attacker (with lower initiative value)
        // Attack first attacker with selected attack type
        // Update GUI for first attacker
        // Wait for some time for user to think what is happening

        Debug.Log("in UPlayer::Fight");

        isFighting = true;

        UnitGUI playerGUI = this.GetComponent<UnitGUI>();
        UnitGUI otherGUI = other.GetComponent<UnitGUI>();

        if (!playerGUI) Debug.Log("No Player GUI");
        if (!otherGUI) Debug.Log("No Other GUI");

        int playerHP = Stats.CurrentHP;
        int enemyHP = other.Stats.CurrentHP;
        while (playerHP > 0 && enemyHP > 0)
        {
            Debug.Log(playerHP + " - " + enemyHP);

            if (playerHP > 0)
            {
                AttackType TP1 = SelectAttackType();
                Attack(other, TP1);
                otherGUI.GUI_Update();
                Debug.Log("Enemy has " + other.Stats.CurrentHP + " HP left.");
                enemyHP = other.Stats.CurrentHP;
            }

            if (enemyHP > 0)
            {
                AttackType TP2 = SelectAttackType();
                other.Attack(this, TP2);
                playerGUI.GUI_Update();
                Debug.Log("Player has " + Stats.CurrentHP + " HP left.");
                playerHP = Stats.CurrentHP;
            }            

            yield return new WaitForSeconds(1.0f);

            if (playerHP <= 0)
            {
                // Animation
                // Destroy
                Debug.Log(this.Name + " DIES. " + other.Name + " WINS.");
            }

            if (enemyHP <= 0)
            {
                // Animation
                otherGUI.gameObject.SetActive(false);
                Destroy(other.gameObject);
                // Destroy(otherGUI);
                // Destroy(other);
                Debug.Log(other.Name + " DIES. " + this.Name + " WINS.");
            }
        }

        isFighting = false;
    }

    public void SetPosition (int x, int y)
    {
        

        // ************************ SHORTVIEW: *****************************
        // *********** cHeCk iF thIs tuRn CouLd bE dOnE aT aLl *************
        // ***** do various actions with objects, items, enemies etc., *****
        // ** if they return true result, which means the object is used, **
        // ***** the item is taken or the enemy is beaten, we can move *****
        // ***** the player to his new position, otherwise, do nothing *****

        if ((x < 0 || x > manager.Width - 1) || (y < 0 || y > manager.Height - 1))
        {
            Debug.Log("You cannot make that move.");
            return;
        }

        previousTI = manager.TileInfoForCoords(currentPosition.x, currentPosition.y);
        currentTI = manager.TileInfoForCoords(x, y);
        if (currentTI != null)
        {            
            bool currentTileTraversable = !currentTI.tile.GetComponent<Tile>().Solid;
            if (!currentTileTraversable)
            {
                Debug.Log("This tile cannot be traversed");

                return;
            }

            bool currentTileEnemy = currentTI.unit;
            if (currentTileEnemy)
            {
                Unit unit = currentTI.unit.GetComponent<Unit>();
                Debug.Log("Enemy Encountered: " + unit.Name);

                StartCoroutine(Fight(unit));

                return;
            }

            bool currentTileStructure = currentTI.structure;
            if (currentTileStructure)
            {
                Structure structure = currentTI.structure.GetComponent<Structure>();
                Debug.Log("Structure Encountered: " + structure.Name);

                structure.Use();
                Destroy(structure.gameObject);
                
                return;
            }

            bool currentTileItem = currentTI.item;
            if (currentTileItem)
            {
                Item item = currentTI.item.GetComponent<Item>();
                Debug.Log("Item Encountered: " + item.Name);

                gui.Activate("itemActions");
                gui.Enable("itemActions - takeButton");
                gui.Disable("itemActions - dropButton");


                // do various stuff with items, in our case
                // show the gui with button "Take" available
                // if user clicks on that button, item moves to bag

                // Destroy(item.gameObject);

                // return;
            }
            else
            {
                gui.Disable("itemActions - takeButton");
                gui.Disable("itemActions - dropButton");
                gui.Deactivate("itemActions");
            }

            transform.position = new Vector3 (currentTI.position.x, currentTI.position.y, 0);
            transform.parent = currentTI.tile.transform;

            currentTI.unit = previousTI.unit;
            previousTI.unit = null;

            currentPosition.x = x;
            currentPosition.y = y;

            Debug.Log("Player's position: " + x + "-" + y);
        }
    }

    public void Move(Direction direction)
    {
        // Player cannot move while he is fighting
        if (isFighting)
            return;

        switch (direction)
        {
            case Direction.UP:
                SetPosition(currentPosition.x, currentPosition.y + 1);
                break;

            case Direction.LEFT:
                SetPosition(currentPosition.x - 1, currentPosition.y);
                break;

            case Direction.DOWN:
                SetPosition(currentPosition.x, currentPosition.y - 1);
                break;

            case Direction.RIGHT:
                SetPosition(currentPosition.x + 1, currentPosition.y);
                break;
        }
    }

    public void HandleKeyboardInput()
    {
        if (Input.GetKeyDown(KeyCode.UpArrow))    Move(Direction.UP);
        if (Input.GetKeyDown(KeyCode.LeftArrow))  Move(Direction.LEFT);
        if (Input.GetKeyDown(KeyCode.DownArrow))  Move(Direction.DOWN);
        if (Input.GetKeyDown(KeyCode.RightArrow)) Move(Direction.RIGHT);
    }

    public void OnTakeButtonClicked()
    {
        Item item = currentTI.item.GetComponent<Item>();
        Debug.Log("in OnTakeButtonClicked.. item name is " + item.Name);
        bag.Take(item);

        Debug.Log("Take Button Clicked");
    }

    public void OnDropButtonClicked()
    {
        Debug.Log("Drop Button Clicked");
    }

    void Awake()
    {
        spawnPosition =   new Position(0, 0);
        currentPosition = new Position(0, 0);

        manager = GameObject.Find("Manager").GetComponent<GameManager>();
        gui = GameObject.Find("Manager").GetComponent<GUI_Manager>();

        bag = GameObject.Find("Inventory").GetComponent<Inventory_Bag>();
        equipment = this.GetComponent<Inventory_Equipment>();
    }

    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        HandleKeyboardInput();
    }
}
