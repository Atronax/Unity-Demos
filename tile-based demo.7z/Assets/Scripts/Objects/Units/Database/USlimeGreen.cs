﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class USlimeGreen : Unit
{
    public override void Attack(Unit other, AttackType attackType)
    {
        if (Stats.CurrentHP <= 0)
            return;

        Stats myStats = base.Stats;
        Stats otherStats = other.GetComponent<Stats>();

        int damage = 0;
        string damage_type = "";
        if (attackType == AttackType.PHYSICAL)
        {
            damage = Random.Range(myStats.Damage_Physical_Min, myStats.Damage_Physical_Max + 1) * Random.Range(1, 3);
            damage_type = "physical";
        }

        if (attackType == AttackType.MAGICAL)
        {
            damage = Random.Range(myStats.Damage_Magical_Min, myStats.Damage_Magical_Max + 1) * Random.Range(2, 4);
            damage_type = "magical";
        }

        if (damage_type == "physical")
            Debug.Log("Green Slime hits player and inflicts " + damage + " damage with his sword.");
        else if (damage_type == "magical")
            Debug.Log("Green Slime hits player and inflicts " + damage + " damage with his poison.");

        otherStats.TakeDamage(damage, attackType);
    }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
