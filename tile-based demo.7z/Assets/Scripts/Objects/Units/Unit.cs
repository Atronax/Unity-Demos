﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

[RequireComponent(typeof(Stats))]
public abstract class Unit : MonoBehaviour
{
    [SerializeField] Texture2D texture;
    [SerializeField] string _name;
    [SerializeField] string description;
    [SerializeField] Stats stats;
    // Inventory inventory { get; set; }       

    public Texture2D Texture
    {
        get { return texture; }
        set { texture = value; }
    }

    public string Name
    {
        get { return _name; }
        set { _name = value; }        
    }

    public string Description
    {
        get { return description; }
        set { description = value; }
    }

    public Stats Stats
    {
        get { return stats; }
        set { stats = value; }
    }    

    // void PreAttack();
    public abstract void Attack(Unit other, AttackType attackType);
    // void PostAttack();
    // void UseItem();
    // void UseSpell();
    // void Die();
}
