﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ItemTextures : MonoBehaviour
{
    [SerializeField] public Texture2D noneTexture;
    [SerializeField] public Texture2D knifeTexture;
    [SerializeField] public Texture2D knifeRagnarekTexture;
}
