﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UnitGUITextures : MonoBehaviour
{
    [SerializeField] public Texture2D currentHP_texture;
    [SerializeField] public Texture2D maximumHP_texture;
    [SerializeField] public Texture2D dmgPhysMin_texture;
    [SerializeField] public Texture2D dmgPhysMax_texture;
    [SerializeField] public Texture2D dmgMagMin_texture;
    [SerializeField] public Texture2D dmgMagMax_texture;
    [SerializeField] public Texture2D defence_texture;
    [SerializeField] public Texture2D resistance_texture;
}
