﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TileTextures : MonoBehaviour
{
    [SerializeField] public Texture2D noneTexture;
    [SerializeField] public Texture2D grassTexture;
    [SerializeField] public Texture2D sandTexture;
    [SerializeField] public Texture2D mountainTexture;
}
