﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UnitPrefabs : MonoBehaviour
{
    [SerializeField] public GameObject nothing;
    [SerializeField] public GameObject player;
    [SerializeField] public GameObject greenSlime;
}
