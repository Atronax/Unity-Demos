﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ItemPrefabs : MonoBehaviour
{
    [SerializeField] public GameObject nothing;
    [SerializeField] public GameObject knife;
    [SerializeField] public GameObject knifeOfRagnarek;
}

