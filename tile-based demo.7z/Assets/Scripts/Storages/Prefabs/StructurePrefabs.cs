﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StructurePrefabs : MonoBehaviour
{
    [SerializeField] public GameObject nothing;
    [SerializeField] public GameObject foodStation;
}
