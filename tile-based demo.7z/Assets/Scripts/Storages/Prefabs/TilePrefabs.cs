﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TilePrefabs : MonoBehaviour
{
    [SerializeField] public GameObject basic;
    [SerializeField] public GameObject grass;
    [SerializeField] public GameObject sand;
    [SerializeField] public GameObject mountain;
}
