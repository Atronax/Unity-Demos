﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

[RequireComponent(typeof(TMEditorSettings))]
public class TMEditor : MonoBehaviour
{
    // reference to the manager that stores the map itself and settings that is used for saving
    GameManager manager;
    TMEditorSettings settings;

    // storages for prefabs of objects that are allowed to be generated
    TilePrefabs tilePrefabs;
    StructurePrefabs structurePrefabs;
    UnitPrefabs unitPrefabs;
    ItemPrefabs itemPrefabs;

    // current element to put on the map
    GameObject currentTilePrefab;
    GameObject currentStructurePrefab;
    GameObject currentUnitPrefab;
    GameObject currentItemPrefab;

    bool playerHasBeenPlaced = false;
    
    // GUI: change size of the map
    InputField sizeField;

    void Awake()
    {
        // все действия с картой мы проводим с помощью класса-посредника, в котором
        // хранится сама карта, объекты, расположенные на ней, персонажи и так далее
        manager = GameObject.Find("Manager").GetComponent<GameManager>();

        // префабы хранятся в отдельных классах-хранилищах, чтобы упростить расширение
        tilePrefabs = GameObject.Find("Prefabs").GetComponent<TilePrefabs>();
        structurePrefabs = GameObject.Find("Prefabs").GetComponent<StructurePrefabs>();
        unitPrefabs = GameObject.Find("Prefabs").GetComponent<UnitPrefabs>();
        itemPrefabs = GameObject.Find("Prefabs").GetComponent<ItemPrefabs>();

        playerHasBeenPlaced = (GameObject.Find("Player") != null);

        // чтобы иметь возможность считать текст с поля ввода, находим соответствующий объект
        // в списке иерархии и присваиваем его компонент InputField переменной sizeField        
        sizeField = GameObject.Find("sizeField").GetComponent<InputField>();

        // сбрасываем выбор текущего элемента для генерации
        ClearSelection();
    }

    void Start()
    {
        InitializeSettings();        
        GenerateDefaultMap();
    }

    // Update is called once per frame
    void Update()
    {
        HandleEditOperations();
        HandleSaveLoadOperations();        
    }

    void ClearSelection()
    {
        currentTilePrefab = null;
        currentStructurePrefab = null;
        currentUnitPrefab = null;
        currentItemPrefab = null;
    }

    void ChangeTile(TileInfo ti)
    {
        Debug.Log("*** working with tiles *** " + currentTilePrefab);

        Tile prefabTile = currentTilePrefab.GetComponent<Tile>();
        Tile selectedTile = ti.tile.GetComponent<Tile>();

        selectedTile.setSurfaceType(prefabTile.getSurfaceType());
    }

    void ChangeStructure(TileInfo ti)
    {
        Debug.Log("*** working with structures *** " + currentStructurePrefab);

        if (currentStructurePrefab == structurePrefabs.nothing)
        {
            Destroy(ti.structure);
            return;
        }

        if (ti.IsReachable() && ti.HasNoStructures())
        {
            Vector3 position = new Vector3(ti.position.x, ti.position.y, 0);
            Quaternion rotation = Quaternion.identity;

            if (ti.structure)
                Destroy(ti.structure);

            GameObject go = Instantiate<GameObject>(currentStructurePrefab, position, rotation, ti.tile.transform);
            ti.structure = go;
        }
        else
            Debug.Log("Structure creation: Tile is NOT reachable || tile HAS objects on top");
    }

    void ChangeUnit(TileInfo ti)
    {
        Debug.Log("*** working with units *** " + currentUnitPrefab);

        if (currentUnitPrefab == unitPrefabs.nothing)
        {
            Destroy(ti.unit);
            return;
        }

        if (ti.IsReachable() && ti.HasNoStructures() && ti.HasNoItems())
        {
            Debug.Log("Tile is Reachable and Has No Structures");

            Vector3 position = new Vector3(ti.position.x, ti.position.y, 0);
            Quaternion rotation = Quaternion.identity;
    
            Debug.Log("Unit creation: Tile is reachable && tile has no objects on top");

            // Херня, переделать                       
            if (ti.unit)
              Destroy(ti.unit);

            GameObject unit = null;
            bool isPlayer = (currentUnitPrefab == unitPrefabs.player);
            if (isPlayer)
            {
                if (GameObject.Find("Player") == null)
                    AddPlayer(ti.position.x, ti.position.y);
            }
            else
                unit = Instantiate<GameObject>(currentUnitPrefab, position, rotation, ti.tile.transform);


            ti.unit = unit;
            Debug.Log("AFTER CREATION: " + ti.unit);
        }
        else
            Debug.Log("Unit creation: Tile is NOT reachable || tile HAS objects on top");    
    }

    void ChangeItem (TileInfo ti)
    {
        Debug.Log("*** working with items *** " + currentItemPrefab);

        if (currentItemPrefab == itemPrefabs.nothing)
        {
            Destroy(ti.item);
            return;
        }

        if (ti.IsReachable() && ti.HasNoStructures() && ti.HasNoUnits())
        {
            Vector3 position = new Vector3(ti.position.x, ti.position.y, 0);
            Quaternion rotation = Quaternion.identity;

            if (ti.item)
                Destroy(ti.item);

            GameObject go = Instantiate<GameObject>(currentItemPrefab, position, rotation, ti.tile.transform);
            ti.item = go;
        }
        else
            Debug.Log("Item creation: Tile is NOT reachable || tile HAS objects on top || tile HAS units on top");
    }

    
    void HandleEditOperations()
    {
        if (Input.GetMouseButtonDown(0))
        {                       
            RaycastHit hit = new RaycastHit();
            
            if (Physics.Raycast(Camera.main.ScreenPointToRay(Input.mousePosition), out hit))
            {
                Tile hitTile = hit.transform.GetComponent<Tile>();

                if (hitTile)
                {
                    Debug.Log("HIT TILE: " + hitTile);

                    TileInfo hitTileInfo = manager.TileInfoForTile(hitTile);                    

                    if (currentTilePrefab)
                        ChangeTile(hitTileInfo);
                    
                    if (currentStructurePrefab)
                        ChangeStructure(hitTileInfo);
                    
                    if (currentUnitPrefab)
                        ChangeUnit(hitTileInfo);

                    if (currentItemPrefab)
                        ChangeItem(hitTileInfo);
                }                
            }
            else
                Debug.Log("RAY OF TMEDITOR : has NOT hit the target");
        }
    }

    void HandleSaveLoadOperations()
    {
        if (Input.GetKey(KeyCode.LeftControl) && Input.GetKey(KeyCode.S))
            settings.SaveMap();

        if (Input.GetKey(KeyCode.LeftControl) && Input.GetKey(KeyCode.L))
            settings.LoadMap();
    }
        
    public void AddTile (int x, int y, SurfaceType type)
    {
        // to generate tile object we need some things:
        // 1. its position on screen - x and y parameters are changing
        // 2. its rotation state - nothing in our case
        // 3. its parent in hierarchy - gameobject tagged with "world" string
        // then we instantiate a game object using base prefab,
        // looking for its tile component and setting a type afterwards,
        // and then add the corresponding tileinfo into map list

        Vector3 position = new Vector3 (x, y, 0.0f);
        Quaternion rotation = Quaternion.identity;
        Transform parent = GameObject.FindGameObjectWithTag("world").transform;

        GameObject tileObject = Instantiate<GameObject>(tilePrefabs.basic, position, rotation, parent);
        tileObject.name = "Tile " + x + "-" + y;

        Tile tile = tileObject.GetComponent<Tile>();
        tile.setSurfaceType(type);

        TileInfo tileInfo = new TileInfo(tileObject, new Position(x, y));
        manager.Tiles.Add(tileInfo);
    }

    public void AddPlayer (int x, int y)
    {        
        TileInfo ti = manager.TileInfoForCoords(x, y);
        Vector3 pos = new Vector3(ti.position.x, ti.position.y, 0);
        Quaternion rot = Quaternion.identity;

        GameObject unit = Instantiate<GameObject>(unitPrefabs.player, pos, rot, ti.tile.transform);
        unit.gameObject.name = "Player";

        UPlayer uplayer = unit.GetComponent<UPlayer>();
        uplayer.SetPosition(ti.position.x, ti.position.y);
    }

    public void AddStructure (int x, int y, StructureType type)
    {
        TileInfo tileInfo = manager.TileInfoForCoords(x, y);

        Vector3 position = Vector3.zero;
        Quaternion rotation = Quaternion.identity;
        Transform parent = tileInfo.tile.transform;

        tileInfo.structure = Instantiate<GameObject>(currentStructurePrefab, position, rotation, parent);
    }
    

    void InitializeSettings()
    {
        settings = GetComponent<TMEditorSettings>();
    }

     void GenerateDefaultMap()
    {
        manager.Clear();

        Debug.Log("Ширина и высота - " + manager.Width + " : " + manager.Height);
        for (int i = 0; i < manager.Width; ++i)        
            for (int j = 0; j < manager.Height; ++j)            
                AddTile(i, j, SurfaceType.SAND);

        AddPlayer(0, 0);
    }

    public void OnChangeSize()
    {
        string value = sizeField.text;

        if (value == "") Debug.Log("OnChangeSize: nothing retrieved");
        else             Debug.Log("OnChangeSize: retrieved value - " + value);

        // на входе получаем строку вида {x*y}, где x - ширина, y - высота тайлмапа
        // применив функцию string.Split с разделителем "*", получим массив строк,
        // распарсим их в целые w и h, с помощью которых построим новую карту
        string[] separate_values = value.Split('*');

        manager.Width = int.Parse(separate_values[0]);        
        manager.Height = int.Parse(separate_values[1]);

        if (manager.Width != 0 && manager.Height != 0)
            GenerateDefaultMap();
        else
            Debug.Log("Width is zero or height is zero. Cannot create new map based on these parameters. ");        
    }
        
    public void OnTileButtons(string what_button)
    {
        ClearSelection();
          
        if (what_button == "none")     currentTilePrefab = tilePrefabs.basic;
        if (what_button == "grass")    currentTilePrefab = tilePrefabs.grass;
        if (what_button == "sand")     currentTilePrefab = tilePrefabs.sand;
        if (what_button == "mountain") currentTilePrefab = tilePrefabs.mountain;       
    }

    public void OnStructureButtons(string what_button)
    {
        ClearSelection();

        Debug.Log("SELECTED: " + what_button);

        if (what_button == "none")         currentStructurePrefab = structurePrefabs.nothing;
        if (what_button == "food station") currentStructurePrefab = structurePrefabs.foodStation;
    }

    public void OnUnitButtons(string what_button)
    {
        ClearSelection();

        if (what_button == "none")        currentUnitPrefab = unitPrefabs.nothing;
        if (what_button == "player")      currentUnitPrefab = unitPrefabs.player;
        if (what_button == "slime_green") currentUnitPrefab = unitPrefabs.greenSlime;
    }

    public void OnItemButtons(string what_button)
    {
        ClearSelection();

        if (what_button == "none")  currentItemPrefab = itemPrefabs.nothing;
        if (what_button == "knife") currentItemPrefab = itemPrefabs.knife;
        if (what_button == "knife of ragnarek") currentItemPrefab = itemPrefabs.knifeOfRagnarek;
    }

    void SaveToFile(string filename)
    {

    }

    void LoadFromFile(string filename)
    {

    }
}
