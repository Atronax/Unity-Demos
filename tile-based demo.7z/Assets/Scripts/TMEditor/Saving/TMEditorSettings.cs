﻿using UnityEngine;
using System.Collections;
using System;

public class TMEditorSettings : MonoBehaviour
{
	// world information
	GameManager manager;

	// saving and loading
	string saveFilename;
	Save saveSubsystem;

	void Awake()
	{
		// We want this object to survive from scene to scene.
		// So we need to tell Unity not to destroy it when loading.
		DontDestroyOnLoad(this);

		// We need reference to manager to have access to manager
		manager = GameObject.Find("Manager").GetComponent<GameManager>();

		// We need to create a GameSave object in order to save our data in file
		saveSubsystem = new Save();
		saveFilename = "test.map";
	}

	// Use this for initialization
	void Start()
	{

		
	}

	// Update is called once per frame
	void Update()
	{
		
	}

	// saving character data
	public void SaveMap()
	{
		GameObject generatorObject = GameObject.Find("Editor");

		// clear dictionaries
		saveSubsystem.DeleteAll();

		// save width and height of the map
		// for each tile that is stored in list:
		// - save its indexes on the field (x & y)
		// - save type of current tile and its other parameters

		saveSubsystem.SetInt("Width", manager.Width);
		saveSubsystem.SetInt("Height", manager.Height);

		for (int i = 0; i < manager.Size(); ++i)
		{
			TileInfo currentTileInfo = manager.TileInfoForIndex(i);
		
			saveSubsystem.SetInt(i + ": Index x", currentTileInfo.position.x);
			saveSubsystem.SetInt(i + ": Index y", currentTileInfo.position.y);

			Tile tile = currentTileInfo.tile.GetComponent<Tile>();
			saveSubsystem.SetString(i + ": Tile type", tile.getSurfaceType().ToString());

			Debug.Log(i + ": Index X: " + currentTileInfo.position.x);
			Debug.Log(i + ": Index Y: " + currentTileInfo.position.y);
			Debug.Log(i + ": Type   : " + tile.getSurfaceType().ToString());
		}


	// flush save into outer file
	saveSubsystem.SaveToFile(ref saveFilename);
		
	}

public void LoadMap()
{
	GameObject generatorObject = GameObject.Find("Editor");
	TMEditor generator = generatorObject.GetComponent<TMEditor>();

	// flush save from outer file
	saveSubsystem.LoadFromFile(ref saveFilename);

	// load width and height of the map
	// for each tile that is saved in file:
	// - load its indexes to integers (x & y)
	// - load type of current tile and its other parameters
	// - use this data to generate tileinfo object
	// - create new gameobject with tile component of corresponding type 

	manager.Clear();

	manager.Width = saveSubsystem.GetInt("Width", 0);
	manager.Height = saveSubsystem.GetInt("Height", 0);

	for (int i = 0; i < manager.Size(); ++i)
	{
		int index_x = saveSubsystem.GetInt(i + ": Index X", 0);
		int index_y = saveSubsystem.GetInt(i + ": Index Y", 0);

		string typeString = saveSubsystem.GetString(i + ": Tile type", "NONE");
		SurfaceType type = stringToSurfaceType(typeString);

		generator.AddTile(index_x, index_y, type);
	}

}

	public SurfaceType stringToSurfaceType(string str)
	{
		SurfaceType type = SurfaceType.NONE;

		Array values = Enum.GetValues(typeof(SurfaceType));
		for (int i = 0; i < values.Length; ++i)
		{
			if (str == Enum.GetName(typeof(SurfaceType), i))
				type = (SurfaceType) values.GetValue(i);
		}

		return type;
	}

}

