﻿using UnityEngine;
using System.IO;
using System.Collections;
using System.Collections.Generic;

public class Save {
	#region public
	public Save()
	{
		m_IntValues = new Dictionary<string, int> ();
		m_BoolValues = new Dictionary<string, bool> ();
		m_FloatValues = new Dictionary<string, float> ();
		m_StringValues = new Dictionary<string, string> ();
		m_Vector2Values = new Dictionary<string, Vector2> ();
		m_Vector3Values = new Dictionary<string, Vector3> ();
		m_QuaternionValues = new Dictionary<string, Quaternion> ();
	}

	// sets values into maps
	public void SetInt(string key, int value)
	{
		m_IntValues.Add (key, value);
	}

	public void SetBool (string key, bool value)
	{
		m_BoolValues.Add (key, value);
	}

	public void SetFloat (string key, float value)
	{
		m_FloatValues.Add (key, value);
	}

	public void SetString (string key, string value)
	{
		m_StringValues.Add (key, value);
	}

	public void SetVector2 (string key, Vector2 value)
	{
		m_Vector2Values.Add (key, value);
	}

	public void SetVector3 (string key, Vector3 value)
	{
		m_Vector3Values.Add (key, value);
	}

	public void SetQuaternion (string key, Quaternion value)
	{
		m_QuaternionValues.Add (key, value);
	}

	// retrieves values from the maps
	public int GetInt (string key, int default_value)
	{
		int Result;

		if (m_IntValues.ContainsKey (key))
			Result = m_IntValues [key];
		else
			Result = default_value;

		return Result;
	}

	public bool GetBool (string key, bool default_value)
	{
		bool Result;

		if (m_BoolValues.ContainsKey (key))
			Result = m_BoolValues [key];
		else
			Result = default_value;

		return Result;
	}

	public float GetFloat (string key, float default_value)
	{
		float Result;

		if (m_FloatValues.ContainsKey (key))
			Result = m_FloatValues [key];
		else
			Result = default_value;

		return Result;
	}

	public string GetString (string key, string default_value)
	{
		string Result;

		if (m_StringValues.ContainsKey (key))
			Result = m_StringValues [key];
		else
			Result = default_value;

		return Result;
	}

	public Vector2 GetVector2 (string key, Vector2 default_value)
	{
		Vector2 Result;

		if (m_Vector2Values.ContainsKey (key))
			Result = m_Vector2Values [key];
		else
			Result = default_value;

		return Result;
	}

	public Vector3 GetVector3 (string key, Vector3 default_value)
	{
		Vector3 Result;

		if (m_Vector3Values.ContainsKey (key))
			Result = m_Vector3Values [key];
		else
			Result = default_value;

		return Result;
	}

	public Quaternion GetQuaternion (string key, Quaternion default_value)
	{
		Quaternion Result;

		if (m_QuaternionValues.ContainsKey (key))
			Result = m_QuaternionValues [key];
		else
			Result = default_value;

		return Result;
	}

	// erases all data in dictionaries
	public void DeleteAll()
	{
		Debug.Log ("in ClearDictionaries");
		
		m_IntValues.Clear ();
		m_BoolValues.Clear ();
		m_FloatValues.Clear ();
		m_StringValues.Clear ();
		m_Vector2Values.Clear ();
		m_Vector3Values.Clear ();
		m_QuaternionValues.Clear ();

		Debug.Log ("Dictionaries cleared");
	}

	// opens savefile with path "path" and fills it with data from dictionaries
	public void SaveToFile (ref string path)
	{
		if (File.Exists(path))
		    File.Delete(path);

		StreamWriter FileWriter = File.CreateText(path);
		
		// save ints
		foreach (KeyValuePair<string, int> entry in m_IntValues)		
			FileWriter.WriteLine("I" + "|" + entry.Key + "|" + entry.Value);
		
		// save bools
		foreach (KeyValuePair<string, bool> entry in m_BoolValues)
			FileWriter.WriteLine("B" + "|" + entry.Key + "|" + entry.Value);
		
		// save floats
		foreach (KeyValuePair<string, float> entry in m_FloatValues)
			FileWriter.WriteLine("F" + "|" + entry.Key + "|" + entry.Value);
		
		// save strings
		foreach (KeyValuePair<string, string> entry in m_StringValues)
			FileWriter.WriteLine("S" + "|" + entry.Key + "|" + entry.Value);

		// save vectors2
		foreach (KeyValuePair<string, Vector2> entry in m_Vector2Values)
			FileWriter.WriteLine ("V2" + "|" + entry.Key + "|" + entry.Value.x + "|" + entry.Value.y);

		// save vectors3
		foreach (KeyValuePair<string, Vector3> entry in m_Vector3Values)
			FileWriter.WriteLine ("V3" + "|" + entry.Key + "|" + entry.Value.x + "|" + entry.Value.y + "|" + entry.Value.z);

		// save quaternions
		foreach (KeyValuePair<string, Quaternion> entry in m_QuaternionValues)
			FileWriter.WriteLine ("Q" + "|" + entry.Key + "|" + entry.Value.x + "|" + entry.Value.y + "|" + entry.Value.z + "|" + entry.Value.w);
		
		FileWriter.Close ();    	

		DeleteAll ();
	}

	// opens savefile with path "path" and fills dictionaries with its data
	public void LoadFromFile (ref string path)
	{
		DeleteAll();

		if (File.Exists (path)) 
		{
			StreamReader FileReader = File.OpenText (path);				
			while (!FileReader.EndOfStream) 
			{
				string[] KeyValuePair = FileReader.ReadLine ().Split ('|');
			
				if (KeyValuePair [0] == "I")
					m_IntValues.Add (KeyValuePair [1], int.Parse (KeyValuePair [2]));
				if (KeyValuePair [0] == "B")
					m_BoolValues.Add (KeyValuePair [1], bool.Parse (KeyValuePair [2]));
				if (KeyValuePair [0] == "F")
					m_FloatValues.Add (KeyValuePair [1], float.Parse (KeyValuePair [2]));
				if (KeyValuePair [0] == "S")
					m_StringValues.Add (KeyValuePair [1], KeyValuePair [2]);
				if (KeyValuePair [0] == "V2")
					m_Vector2Values.Add (KeyValuePair [1], new Vector2(float.Parse(KeyValuePair[2]), float.Parse(KeyValuePair[3])));
				if (KeyValuePair [0] == "V3")
					m_Vector3Values.Add (KeyValuePair [1], new Vector3(float.Parse(KeyValuePair[2]), float.Parse(KeyValuePair[3]), float.Parse(KeyValuePair[4])));			
				if (KeyValuePair [0] == "Q")
					m_QuaternionValues.Add (KeyValuePair[1], new Quaternion(float.Parse(KeyValuePair[2]), float.Parse(KeyValuePair[3]), float.Parse(KeyValuePair[4]), float.Parse(KeyValuePair[5])));
			}
		
			FileReader.Close ();	
		}
	}
	#endregion

	#region private
	Dictionary<string, int> m_IntValues;
	Dictionary<string, bool> m_BoolValues;
	Dictionary<string, float> m_FloatValues;
	Dictionary<string, string> m_StringValues;
	Dictionary<string, Vector2> m_Vector2Values;
	Dictionary<string, Vector3> m_Vector3Values;
	Dictionary<string, Quaternion> m_QuaternionValues;
	#endregion
}
