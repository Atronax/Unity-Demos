﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IDestructible
{
    int CurDurability { get; }
    int MaxDurability { get; }

    void Break(int pts);
    void Repair(int pts);

    void BreakEffect();
    void RepairEffect();   
}
