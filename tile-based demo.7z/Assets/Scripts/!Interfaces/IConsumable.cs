﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IConsumable
{
    int consume_count { get; set; }

    void Consume();
}
