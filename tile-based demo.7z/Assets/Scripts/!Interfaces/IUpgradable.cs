﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IUpgradable
{
    int Level { get; }
    int RequiredGold { get; set; }

    void Upgrade();    
}
