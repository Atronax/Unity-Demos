﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IStackable
{
    int count_inStack { get; set; }

    void AddToStack();
    void RemoveFromStack();
}
