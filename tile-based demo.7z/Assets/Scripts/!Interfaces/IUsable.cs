﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IUsable
{
    int uses_count { get; set; }

    void Use();
}
