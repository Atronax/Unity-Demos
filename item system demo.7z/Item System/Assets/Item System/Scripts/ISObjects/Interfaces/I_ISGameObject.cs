﻿using UnityEngine;
using System.Collections;

namespace RPG.ItemSystem
{
	public interface I_ISGameObject
	{
		GameObject Prefab { get; }
	}
}