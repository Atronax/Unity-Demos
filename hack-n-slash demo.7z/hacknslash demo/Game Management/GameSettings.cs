﻿using UnityEngine;
using System.Collections;
using System;

public class GameSettings : MonoBehaviour {

	void Awake ()
	{
		// We want this object to survive from scene to scene.
		// So we need to tell Unity not to destroy it when loading.
		DontDestroyOnLoad (this); 

		// We need to create a GameSave object in order to save our data in file
		m_CurrentSave = new GameSave ();
		m_CurrentSaveFilename = "Save00.hns";
	}

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}

	#region public

	// accessors
	public string CurrentSaveFilename
	{
		get { return m_CurrentSaveFilename;}
		set { m_CurrentSaveFilename = value + ".hns";}
	}

	// saving character data
	public void SaveCharacterData()
	{
		GameObject PlayerController = GameObject.Find("Player");
		PlayerCharacter PlayerCharacter = PlayerController.GetComponent<PlayerCharacter> ();

		// clear dictionaries
		m_CurrentSave.DeleteAll ();

		// save position and rotation
		m_CurrentSave.SetVector3 ("Player Position", PlayerController.transform.position);
		m_CurrentSave.SetQuaternion ("Player Rotation", PlayerController.transform.rotation);

		// save name
		m_CurrentSave.SetString("Player Name", PlayerCharacter.Name);

		// save attributes
		for (int i = 0; i < Enum.GetValues(typeof(AttributeType)).Length; ++i) 
		{
			// base stat inherited
			m_CurrentSave.SetInt (((AttributeType)i).ToString () + " - Base Value", PlayerCharacter.GetAttribute (i).Base);
			m_CurrentSave.SetInt (((AttributeType)i).ToString () + " - Buff Value", PlayerCharacter.GetAttribute (i).Buff);
			m_CurrentSave.SetInt (((AttributeType)i).ToString () + " - Debuff Value", PlayerCharacter.GetAttribute (i).Debuff);
			m_CurrentSave.SetInt (((AttributeType)i).ToString () + " - Exp To Lvl", PlayerCharacter.GetAttribute(i).ExperienceToNextLevel);

			// attributes info
		}

		// save vitalities
		for (int i = 0; i < Enum.GetValues(typeof(VitalityType)).Length; ++i) 
		{
			// base stat inherited
			m_CurrentSave.SetInt (((VitalityType)i).ToString () + " - Base Value", PlayerCharacter.GetVitality (i).Base);
			m_CurrentSave.SetInt (((VitalityType)i).ToString () + " - Buff Value", PlayerCharacter.GetVitality (i).Buff);
			m_CurrentSave.SetInt (((VitalityType)i).ToString () + " - Debuff Value", PlayerCharacter.GetVitality (i).Debuff);
			m_CurrentSave.SetInt (((VitalityType)i).ToString () + " - Exp To Lvl", PlayerCharacter.GetVitality (i).ExperienceToNextLevel);

			// modified stat inherited
			// PlayerPrefs.SetString(((VitalityType)i).ToString () + " - Modifiers", PlayerCharacter.GetVitality(i).GetModifiersAsString());

			// vitality info
			m_CurrentSave.SetInt (((VitalityType)i).ToString () + " - Curr Value", PlayerCharacter.GetVitality(i).Current);
		}

		// save skills
		for (int i = 0; i < Enum.GetValues(typeof(SkillType)).Length; ++i) 
		{
			// base stat inherited
			m_CurrentSave.SetInt (((SkillType)i).ToString () + " - Base Value", PlayerCharacter.GetSkill (i).Base);
			m_CurrentSave.SetInt (((SkillType)i).ToString () + " - Buff Value", PlayerCharacter.GetSkill (i).Buff);
			m_CurrentSave.SetInt (((SkillType)i).ToString () + " - Debuff Value", PlayerCharacter.GetSkill (i).Debuff);
			m_CurrentSave.SetInt (((SkillType)i).ToString () + " - Exp To Lvl", PlayerCharacter.GetSkill (i).ExperienceToNextLevel);

			// modified stat inherited
			// PlayerPrefs.SetString(((SkillType)i).ToString () + " - Modifiers", PlayerCharacter.GetSkill(i).GetModifiersAsString());

			// skill info
		}

		// flush save into outer file
		m_CurrentSave.SaveGame (ref m_CurrentSaveFilename);
		
	}
	
	public void LoadCharacterData()
	{
		GameObject PlayerController = GameObject.Find("Player");
		PlayerCharacter PlayerCharacter = PlayerController.GetComponent<PlayerCharacter> ();

		// flush save from outer file
		m_CurrentSave.LoadGame (ref m_CurrentSaveFilename);

		// load position and rotation
		PlayerController.transform.position = m_CurrentSave.GetVector3 ("Player Position", Vector3.zero);
		PlayerController.transform.rotation = m_CurrentSave.GetQuaternion ("Player Rotation", Quaternion.identity);

		// load name
		PlayerCharacter.Name = m_CurrentSave.GetString ("Player Name", "Default");
		Debug.Log(PlayerCharacter.Name);

		// load attributes
		for (int i = 0; i < Enum.GetValues(typeof(AttributeType)).Length; ++i) 
		{
			// base stat inherited
			PlayerCharacter.GetAttribute(i).Base = m_CurrentSave.GetInt (((AttributeType)i).ToString () + " - Base Value", 0);
			PlayerCharacter.GetAttribute(i).Buff = m_CurrentSave.GetInt (((AttributeType)i).ToString () + " - Buff Value", 0);
			PlayerCharacter.GetAttribute(i).Debuff = m_CurrentSave.GetInt (((AttributeType)i).ToString () + " - Debuff Value", 0);
			PlayerCharacter.GetAttribute(i).ExperienceToNextLevel = m_CurrentSave.GetInt (((AttributeType)i).ToString () + " - Exp To Lvl", 0);
			
			// attributes info

			// debug
			// Debug.Log(PlayerCharacter.GetAttribute(i).Base + " " + PlayerCharacter.GetAttribute(i).ExperienceToNextLevel);
		}

		// load vitalities
		for (int i = 0; i < Enum.GetValues(typeof(VitalityType)).Length; ++i) 
		{
			// base stat inherited
			PlayerCharacter.GetVitality(i).Base = m_CurrentSave.GetInt (((VitalityType)i).ToString () + " - Base Value", 0);
			PlayerCharacter.GetVitality(i).Buff = m_CurrentSave.GetInt (((VitalityType)i).ToString () + " - Buff Value", 0);
			PlayerCharacter.GetVitality(i).Debuff = m_CurrentSave.GetInt (((VitalityType)i).ToString () + " - Debuff Value", 0);
			PlayerCharacter.GetVitality(i).ExperienceToNextLevel = m_CurrentSave.GetInt (((VitalityType)i).ToString () + " - Exp To Lvl", 0);
			
			// modified stat inherited
			PlayerCharacter.GetVitality(i).Update();
			
			// vitality info
			PlayerCharacter.GetVitality(i).Current = m_CurrentSave.GetInt (((VitalityType)i).ToString () + " - Curr Value", 1);

			// debug
			// Debug.Log(PlayerCharacter.GetVitality(i).Base + " " + PlayerCharacter.GetVitality(i).Current + " " + PlayerCharacter.GetVitality(i).ExperienceToNextLevel); 
		}

		// load skills
		for (int i = 0; i < Enum.GetValues(typeof(SkillType)).Length; ++i) 
		{
			// base stat inherited
			PlayerCharacter.GetSkill(i).Base = m_CurrentSave.GetInt (((SkillType)i).ToString () + " - Base Value", 0);
			PlayerCharacter.GetSkill(i).Buff = m_CurrentSave.GetInt (((SkillType)i).ToString () + " - Buff Value", 0);
			PlayerCharacter.GetSkill(i).Debuff = m_CurrentSave.GetInt (((SkillType)i).ToString () + " - Debuff Value", 0);
			PlayerCharacter.GetSkill(i).ExperienceToNextLevel = m_CurrentSave.GetInt (((SkillType)i).ToString () + " - Exp To Lvl", 0);
			
			// modified stat inherited
			PlayerCharacter.GetSkill(i).Update();
			
			// skill info

			// debug
			// Debug.Log(PlayerCharacter.GetSkill(i).GetTranslationOf(((SkillType)i).ToString()) + "-" + PlayerCharacter.GetSkill(i).Total + ":" + PlayerCharacter.GetSkill(i).ExperienceToNextLevel);
		}

	}
	#endregion

	#region private
	// saving and loading
	private string m_CurrentSaveFilename;
	private GameSave m_CurrentSave;
	#endregion
}
