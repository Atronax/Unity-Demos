﻿using UnityEngine;
using System.Collections;

public class GameMaster : MonoBehaviour 
{
	#region public
	// Use this for initialization
	public void Awake () 
	{
		// find or create a player spawn point
		GameObject PlayerSpawnPoint = GameObject.Find("Player Spawn Point");
		if (PlayerSpawnPoint == null) 
		{
			Debug.Log("No Player Spawn Point. Creating New One...");
			PlayerSpawnPoint = (GameObject)Instantiate (m_PlayerSpawnPointPrefab, Vector3.zero, Quaternion.identity);
		}
		
		// instantiate player object and camera object
		m_Player = (GameObject)Instantiate(m_PlayerPrefab, PlayerSpawnPoint.transform.position, PlayerSpawnPoint.transform.rotation);
		// m_PlayerCharacter = m_Player.GetComponent<PlayerCharacter> ();
		m_Player.name = "Player";
		
		GameObject Cam = (GameObject)Instantiate (m_CameraPrefab, Vector3.zero, Quaternion.identity);
		// OrbitCam CamControl = Cam.GetComponent<OrbitCam> (); // orbit camera, v.01
		// OrbitCam2 CamControl = Cam.GetComponent<OrbitCam2> (); // orbit camera, v.02
		// CamControl.Target = m_Player;
		HNSCam CamControl = Cam.GetComponent<HNSCam> (); // hack and slash camera, v.01
		GameObject CamTarget = GameObject.FindGameObjectWithTag ("Camera Target");
		if (CamTarget != null)
			CamControl.m_TargetTransform = CamTarget.transform;
		else
			CamControl.m_TargetTransform = m_Player.transform;

		Cam.name = "Camera";
	}
	
	public void Start()
	{
		LoadCharacter (); // load character data
		ResetPlayerPosition (); // FOR DEBUG USES ONLY		
	}
	
	// Update is called once per frame
	public void Update () 
	{
		if (Input.GetKeyUp (KeyCode.R))
			ResetPlayerPosition ();	
	}

	public GameObject m_GameSettingsPrefab; // Prefab to create game settings object
	public GameObject m_PlayerPrefab, m_CameraPrefab; // Prefab to create character
	public GameObject m_PlayerSpawnPointPrefab; // Prefab of place for character to instantiate
	#endregion

	#region private
	private void ResetPlayerPosition()
	{
		m_Player.transform.position = GameObject.Find ("Player Spawn Point").transform.position;
	}

	private void LoadCharacter ()
	{
		GameObject GameSettingsObject = GameObject.Find ("Game Settings");
		if (GameSettingsObject == null) 
		{
			GameSettingsObject = (GameObject)Instantiate(m_GameSettingsPrefab, Vector3.zero, Quaternion.identity);
			GameSettingsObject.name = "Game Settings";
		}
		
		GameSettings GameSettings = GameSettingsObject.GetComponent<GameSettings> ();
		GameSettings.LoadCharacterData ();
	}

	private GameObject m_Player;
	// private PlayerCharacter m_PlayerCharacter;
	#endregion
}
