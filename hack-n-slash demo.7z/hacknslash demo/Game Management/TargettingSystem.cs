﻿/// <summary>
/// Targetting2.
/// September 2, 2015
/// Max Zamana
/// 
/// Represents targetting system of the game. 
/// Allows player to target mobs at the scene. 
/// Script can be attached to any permanent gameobject.
/// </summary>

using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class TargettingSystem : MonoBehaviour 
{
	#region public
	// Use this for initialization
	void Start () 
	{
		m_AllTargets = new List<GameObject> ();
		m_CurrentIndex = 0;
		m_CurrentTarget = null;
		m_Transform = transform;	
	}
	
	// Update is called once per frame
	void Update () 
	{
		if (Input.GetKeyDown (KeyCode.Tab))
			NextTarget ();
		if (Input.GetKeyDown (KeyCode.Space))
			UnselectPreviousEnemy ();
	}
	
	// Accessors
	public List<GameObject> AllTargets
	{
		get {return m_AllTargets;}
	}
	
	public GameObject CurrentTarget
	{
		get {return m_CurrentTarget;}
	}
	
	// next target function
	public void NextTarget()
	{
		if (++m_CurrentIndex > m_AllTargets.Count - 1)
			m_CurrentIndex = 0;
		
		SortTargetsByDistance();
		UnselectPreviousEnemy();
		m_CurrentTarget = m_AllTargets[m_CurrentIndex];
		SelectCurrentEnemy ();
	}
	
	// Helping functions
	public void PushAllEnemies()
	{
		GameObject[] enemies = GameObject.FindGameObjectsWithTag("Enemy");
		foreach (GameObject enemy in enemies)
			PushOneEnemy(enemy);
	}
	
	public void PushOneEnemy(GameObject enemy)
	{
		m_AllTargets.Add(enemy);
	}
	
	#endregion
	
	#region private
	private void SortTargetsByDistance()
	{
		m_AllTargets.Sort(delegate(GameObject t1, GameObject t2)
		                  { return (Vector3.Distance(t1.transform.position, m_Transform.transform.position)).CompareTo(Vector3.Distance(t2.transform.position, m_Transform.position));});
	}
	
	private void SelectCurrentEnemy()
	{
		Transform CurrentEnemyName = m_CurrentTarget.transform.FindChild("Name");
		if (CurrentEnemyName == null)
			Debug.LogError ("Could not fild the Name of the " + m_CurrentTarget.name);

		MeshRenderer CurrentEnemyNameRenderer = CurrentEnemyName.GetComponent<MeshRenderer> ();
		CurrentEnemyNameRenderer.enabled = true;

		MobCharacter CurrentEnemyData = m_CurrentTarget.GetComponent<MobCharacter> ();
		Messenger<bool>.Broadcast ("Show target vitalbars", true);
		CurrentEnemyData.DisplayHealth ();
	}
	
	private void UnselectPreviousEnemy()
	{
		if (m_CurrentTarget) 
		{
			Transform CurrentEnemyName = m_CurrentTarget.transform.FindChild ("Name");
			if (CurrentEnemyName == null)
				Debug.LogError ("Could not fild the Name of the " + m_CurrentTarget.name);
		
			MeshRenderer CurrentEnemyNameRenderer = CurrentEnemyName.GetComponent<MeshRenderer> ();
			CurrentEnemyNameRenderer.enabled = false;

			Messenger<bool>.Broadcast ("Show target vitalbars", false);

			m_CurrentTarget = null;
		}
	}
	
	public List<GameObject> m_AllTargets;
	public GameObject m_CurrentTarget;
	private int m_CurrentIndex;
	
	private Transform m_Transform;
	#endregion
}
