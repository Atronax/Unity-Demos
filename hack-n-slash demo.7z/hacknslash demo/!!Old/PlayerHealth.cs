﻿using UnityEngine;
using System.Collections;

public class PlayerHealth : MonoBehaviour 
{
	void Start () 
	{
		m_WidthHealthbar = Screen.width * m_CurrentHealth / m_MaximumHealth;	
	}
	
	void Update () 
	{
		AdjustHealth(0);	
	}
	
	void OnGUI ()
	{
		// setup style
		GUI.skin.box.normal.background = background_texture;
		GUI.skin.box.normal.textColor = new Color(1.0f - (float)m_CurrentHealth/(float)m_MaximumHealth, (float)m_CurrentHealth/(float)m_MaximumHealth, 0.0f);
		
		// setup healthbar rects' position and size
		GUI.Box(new Rect(new Vector2((Screen.width - m_WidthHealthbar)/2.0f, 10), new Vector2(m_WidthHealthbar, 20)), m_CurrentHealth + " из " + m_MaximumHealth);
	}

	#region public
	// accessors
	public int CurrentHealth
	{
		get { return m_CurrentHealth;}
		set { m_CurrentHealth = value;}
	}

	public int MaximumHealth
	{
		get { return m_MaximumHealth;}
		set { m_MaximumHealth = value;}
	}

	// function to adjust player hp
	public void AdjustHealth (int adjustment)
	{
		m_CurrentHealth += adjustment;
		if (m_CurrentHealth < 0)
			m_CurrentHealth = 0;
		if (m_CurrentHealth > m_MaximumHealth)
			m_CurrentHealth = m_MaximumHealth;
		if (m_MaximumHealth < 1)
			m_MaximumHealth = 1;

		m_WidthHealthbar = Screen.width * m_CurrentHealth / m_MaximumHealth;
	}

	// public variables
	public Texture2D background_texture;

	public float m_WidthHealthbar;
	public int m_CurrentHealth = 100;
	public int m_MaximumHealth = 100;
	#endregion

	#region private
	#endregion
}

