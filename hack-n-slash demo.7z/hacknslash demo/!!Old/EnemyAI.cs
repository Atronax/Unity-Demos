﻿using UnityEngine;
using System.Collections;

public class EnemyAI : MonoBehaviour 
{
	#region public
	// Before anything else in the script
	void Awake ()
	{
		Target = GameObject.FindGameObjectWithTag("Player").transform;

		m_Transform = transform;
		m_OriginalPosition = transform.position;
	}	

	// Use this for initialization
	void Start () 
	{
		m_AttackRange = 5.0f;
	}
	
	// Update is called once per frame
	void Update () 
	{
		if (m_Target) 
		{
			Debug.DrawLine (m_Transform.position, m_Target.position);

			if (Vector3.Distance (m_Target.position, m_Transform.position) < m_AttackRange) 
			{ // Look at target and move there if it in the attack range
				m_Transform.rotation = Quaternion.Slerp (m_Transform.rotation, Quaternion.LookRotation (m_Target.position - m_Transform.position, Vector3.up), m_RotationSpeed * Time.deltaTime);
				m_Transform.position += m_Transform.forward * m_MovingSpeed * Time.deltaTime;
			} 
			else if (m_Transform.position != m_OriginalPosition) 
			{ // Move to its original position otherwise
				Vector3 OriginDirection = m_OriginalPosition - m_Transform.position;
				m_Transform.position += OriginDirection * m_MovingSpeed * Time.deltaTime;
			}
		}
	}

	// accessors
	public Transform Target
	{
		get {return m_Target;}
		set {m_Target = value;}
	}

	public Transform m_Target;
	public float m_AttackRange;
	public int m_MovingSpeed = 5;
	public int m_RotationSpeed = 3;
	#endregion

	#region private
	private Vector3 m_OriginalPosition;
	private Transform m_Transform;
	#endregion


}
