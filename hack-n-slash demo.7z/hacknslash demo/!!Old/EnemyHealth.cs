﻿using UnityEngine;
using System.Collections;

public class EnemyHealth : MonoBehaviour 
{
	#region public
	// Use this for initialization
	void Start () 
	{
		Targetting = GameObject.FindGameObjectWithTag("Player").GetComponent<Targetting>();

		// calculate healthbar width
		m_WidthHealthbar = Screen.width * m_CurrentHealth / m_MaximumHealth;	

		// initialize targetting
		m_IsTargetted = false;
	}
	
	// Update is called once per frame
	void Update () 
	{
		AdjustHealth(0);	
	}
	
	void OnGUI ()
	{
		// if player targetted this instance
		if (m_IsTargetted) 
		{
			// setup style
			GUI.skin.box.normal.background = background_texture;
			GUI.skin.box.normal.textColor = new Color (1.0f - (float)m_CurrentHealth / (float)m_MaximumHealth, (float)m_CurrentHealth / (float)m_MaximumHealth, 0.0f);
		
			// setup healthbar rects' position and size
			GUI.Box (new Rect (new Vector2 ((Screen.width - m_WidthHealthbar) / 2.0f, 40), new Vector2 (m_WidthHealthbar, 20)), m_CurrentHealth + " из " + m_MaximumHealth);
		}
	}

	// accessors
	public Targetting Targetting
	{
		get {return m_Targetting;}
		set {m_Targetting = value;}
	}

	public bool IsTargetted
	{
		get { return m_IsTargetted;}
		set { m_IsTargetted = value;}
	}

	// function to adjust hp
	public void AdjustHealth (int adjustment)
	{
		m_CurrentHealth += adjustment;

		if (m_CurrentHealth > m_MaximumHealth)
			m_CurrentHealth = m_MaximumHealth;
		if (m_MaximumHealth < 1)
			m_MaximumHealth = 1;
		if (m_CurrentHealth <= 0) 
			RemoveEnemy(gameObject);

		m_WidthHealthbar = Screen.width * m_CurrentHealth / m_MaximumHealth;
	}


	public Texture2D background_texture;
	public int m_CurrentHealth = 100;
	public int m_MaximumHealth = 100;
	#endregion
	
	#region private
	private void RemoveEnemy (GameObject enemy)
	{
		// remove object from targetting list
		m_Targetting.AllTargets.Remove(enemy);

		// set next target
		if (m_Targetting.AllTargets.Count != 0)
			m_Targetting.NextTarget();

		// destroy object
		Destroy(enemy);
	}

	private float m_WidthHealthbar;
	private Targetting m_Targetting;
	private bool m_IsTargetted;
	#endregion
}
