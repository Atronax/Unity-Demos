﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Targetting : MonoBehaviour 
{
	#region public
	// Use this for initialization
	void Start () 
	{
		m_AllTargets = new List<GameObject> ();
		m_CurrentIndex = 0;
		m_CurrentTarget = null;
		m_Transform = transform;

		PushAllEnemies ();
	}
	
	// Update is called once per frame
	void Update () 
	{
		if (Input.GetKeyDown (KeyCode.Tab))
			NextTarget ();
	}

	// Accessors
	public List<GameObject> AllTargets
	{
		get {return m_AllTargets;}
	}

	public GameObject CurrentTarget
	{
		get {return m_CurrentTarget;}
	}

	// next target function
	public void NextTarget()
	{
		if (++m_CurrentIndex > m_AllTargets.Count - 1)
			m_CurrentIndex = 0;

		SortTargetsByDistance();
		UnselectPreviousEnemy();
		m_CurrentTarget = m_AllTargets[m_CurrentIndex];
		SelectCurrentEnemy ();
	}

	// Helping functions
	public void PushAllEnemies()
	{
		GameObject[] enemies = GameObject.FindGameObjectsWithTag("Enemy");
		foreach (GameObject enemy in enemies)
			PushOneEnemy(enemy);
	}

	public void PushOneEnemy(GameObject enemy)
	{
		m_AllTargets.Add(enemy);
	}

	#endregion

	#region private
	private void SortTargetsByDistance()
	{
		m_AllTargets.Sort(delegate(GameObject t1, GameObject t2)
			{ return (Vector3.Distance(t1.transform.position, m_Transform.transform.position)).CompareTo(Vector3.Distance(t2.transform.position, m_Transform.position));});
	}

	private void SelectCurrentEnemy()
	{
		if (m_CurrentTarget) 
		{
			// MeshRenderer target_renderer = m_CurrentTarget.GetComponent<MeshRenderer> ();
			// target_renderer.material.color = Color.red;

			// EnemyHealth target_health = m_CurrentTarget.GetComponent<EnemyHealth>();
			// target_health.IsTargetted = true;

			// PlayerAttack player_attack = GameObject.FindGameObjectWithTag("Player").GetComponent<PlayerAttack>();
			// player_attack.Target = m_CurrentTarget;
		}
	}

	private void UnselectPreviousEnemy()
	{
		if (m_CurrentTarget) 
		{
			// MeshRenderer target_renderer = m_CurrentTarget.GetComponent<MeshRenderer> ();
			// target_renderer.material.color = Color.blue;

			// EnemyHealth target_health = m_CurrentTarget.GetComponent<EnemyHealth>();
			// target_health.IsTargetted = false;

			// PlayerAttack player_attack = GameObject.FindGameObjectWithTag("Player").GetComponent<PlayerAttack>();
			// player_attack.Target = null;
			// m_CurrentTarget = null;
		}
	}

	public List<GameObject> m_AllTargets;
	public GameObject m_CurrentTarget;
	private int m_CurrentIndex;

	private Transform m_Transform;
	#endregion
}
