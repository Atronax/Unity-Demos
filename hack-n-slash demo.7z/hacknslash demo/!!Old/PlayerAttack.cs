﻿using UnityEngine;
using System.Collections;

public class PlayerAttack : MonoBehaviour 
{
	#region public
	// Use this for initialization
	void Start () 
	{
		m_AttackTimer = 0.0f;
		m_AttackCooldown = 2.0f;
	}
	
	// Update is called once per frame
	void Update () 
	{
		UpdateAttackTimer ();
		if (m_Target && Input.GetKeyUp (KeyCode.F)) 
		{
			if (m_AttackTimer == 0.0f)
				Attack ();
		}
	}

	public GameObject Target
	{
		get { return m_Target;}
		set { m_Target = value;}
	}

	public GameObject m_Target;
	public float m_AttackTimer;
	public float m_AttackCooldown;
	#endregion

	#region private
	private void UpdateAttackTimer()
	{
		if (m_AttackTimer > 0.0f)
			m_AttackTimer -= Time.deltaTime;
		
		if (m_AttackTimer <= 0.0f) 		
			m_AttackTimer = 0.0f;
	}

	private void Attack()
	{
		Vector3 dir_vector = (m_Target.transform.position - transform.position).normalized;

		float distance = Vector3.Distance (m_Target.transform.position, transform.position); // distance between player and its target
		float direction = Vector3.Dot (dir_vector, transform.forward); // dot product or cos of angle between direction and player forward vectors

		Debug.Log (distance);
		Debug.Log (direction);

		if (distance < 2.0f && direction > 0) 
		{
			EnemyHealth enemy_health = m_Target.GetComponent<EnemyHealth> ();
			enemy_health.AdjustHealth (Random.Range(-50, -20));

			m_AttackTimer = m_AttackCooldown;
		}
	}
	#endregion

}
