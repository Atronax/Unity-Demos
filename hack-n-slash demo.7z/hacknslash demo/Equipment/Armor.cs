﻿/// <summary>
/// Armor.
/// September 30, 2015
/// Author: Zamana Maxym
/// 
/// Represents armor characteristics of the game. Currently used for saving armor level.
/// </summary>

using UnityEngine;

public class Armor : Clothing 
{
	#region public
	/// <summary>
	/// Initializes a new instance of the <see cref="Armor"/> class with zeroed armor level .
	/// </summary>
	public Armor()
	{
		m_ArmorLevel = 0;
	}

	/// <summary>
	/// Initializes a new instance of the <see cref="Armor"/> class with armor level int param.
	/// </summary>
	/// <param name="ArmorLevel">Armor level.</param>
	public Armor (int ArmorLevel)
	{
		m_ArmorLevel = ArmorLevel;
	}

	/// <summary>
	/// ArmorLevel accessors: gets or sets the armor level.
	/// </summary>
	/// <value>The armor level.</value>
	public int ArmorLevel
	{
		get { return m_ArmorLevel;}
		set { m_ArmorLevel = Value;}
	}
	#endregion

	#region private
	private int m_ArmorLevel;
	#endregion
}
