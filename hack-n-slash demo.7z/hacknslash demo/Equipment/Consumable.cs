﻿/// <summary>
/// Consumable.
/// September 30, 2015
/// Author: Zamana Maxym
/// 
/// Represent game's consumables logic. Food, potions, different medalions and other stuff belongs here.
/// </summary>

using UnityEngine;

public class Consumable : BuffItem
{
	#region public
	/// <summary>
	/// Initializes a new instance of the <see cref="Consumable"/> class with defaults.
	/// </summary>
	public Consumable()
	{
		Reset ();
	}

	/// <summary>
	/// Initializes a new instance of the <see cref="Consumable"/> class with user params.
	/// </summary>
	/// <param name="VitalitiesAffected">Vitalities affected.</param>
	/// <param name="AmountToRestore">Amount to restore.</param>
	/// <param name="RestorationTime">Restoration time.</param>
	public Consumable(Vitality[] VitalitiesAffected, int[] AmountToRestore, float RestorationTime)
	{
		m_VitalitiesAffected = VitalitiesAffected;
		m_AmountToRestore = AmountToRestore;
		m_RestorationTime = RestorationTime;
	}

	/// <summary>
	/// Resets this instance.
	/// </summary>
	public void Reset()
	{
		// ???
		for (int i = 0; i < m_VitalitiesAffected.Length; ++i) 
		{
			m_VitalitiesAffected[i] = new Vitality();
			m_AmountToRestore[i] = 0;
		}
		
		m_RestorationTime = 0;
	}

	/// <summary>
	/// Returns count of the vitalities affected.
	/// </summary>
	/// <returns>Count of vitalities affected.</returns>
	public int CountOfVitalitiesAffected()
	{
		return m_VitalitiesAffected.Length;
	}

	/// <summary>
	/// Returns affected vitality at index set in the param.
	/// </summary>
	/// <returns>Affected vitality.</returns>
	/// <param name="Index">Index of needed affected vitality.</param>
	public Vitality VitalityAffectedAtIndex (int Index)
	{
		if (Index >= 0 && Index < m_VitalitiesAffected.Length)
			return m_VitalitiesAffected [Index];
		else
			return new Vitality ();
	}

	/// <summary>
	/// Returns restoration value of the vitality by its index.
	/// </summary>
	/// <returns>The restoration value.</returns>
	/// <param name="Index">Index of vitality.</param>
	public int RestorationValueAtIndex (int Index)
	{
		if (Index >= 0 && Index < m_AmountToRestore.Length)
			return m_AmountToRestore [Index];
		else
			return 0;
	}

	/// <summary>
	/// Sets the vitality at Index to Vital.
	/// </summary>
	/// <param name="Index">Index.</param>
	/// <param name="Vital">Vital.</param>
	public void SetVitalityAt (int Index, Vitality Vital)
	{
		if (Index >= 0 && Index < m_VitalitiesAffected.Length) 		
			m_VitalitiesAffected[Index] = Vital;
	}

	/// <summary>
	/// Sets the restoration value at Index to Restoration.
	/// </summary>
	/// <param name="Index">Index.</param>
	/// <param name="Restoration">Restoration.</param>
	public void SetRestorationAt (int Index, int Restoration)
	{
		if (Index >= 0 && Index < m_AmountToRestore.Length) 		
			m_AmountToRestore[Index] = Restoration;
	}

	public void SetVitalityAndRestorationAt (int Index, Vitality Vital, int Restoration)
	{
		SetVitalityAt (Index, Vital);
		SetRestorationAt (Index, Restoration);
	}

	/// <summary>
	/// Restoration Time accessors: gets or sets the restoration time.
	/// </summary>
	/// <value>The restoration time.</value>
	public float RestorationTime
	{
		get { return m_RestorationTime;}
		set { m_RestorationTime = value;}
	}
	#endregion

	#region private
	private Vitality[] m_VitalitiesAffected;
	private int[] m_AmountToRestore;
	private float m_RestorationTime;
	#endregion
}
