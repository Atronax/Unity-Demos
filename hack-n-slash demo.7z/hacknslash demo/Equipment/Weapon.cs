﻿public class Weapon : BuffItem 
{
	#region public 
	public enum DamageType {Bludgeon, Pierce, Slash, 
							Fire, Ice, Lightning, Poison};

	public Weapon()
	{
		m_DamageType = DamageType.Bludgeon;
		m_MinimalDamage = m_MaximalDamage = 0;
		m_Range = 0;
	}

	public Weapon (DamageType Type, int MinDamage, int MaxDamage, float Range)
	{
		m_DamageType = Type;
		m_MinimalDamage = MinDamage;
		m_MaximalDamage = MaxDamage;
		m_Range = Range;
	}

	// accessors
	public DamageType TypeOfDamage
	{
		get { return m_DamageType;}
		set { m_DamageType = value;}
	}

	public int MinimalDamage
	{
		get { return m_MinimalDamage;}
		set { m_MinimalDamage = value;}
	}

	public int MaximalDamage
	{
		get { return m_MaximalDamage;}
		set { m_MaximalDamage = value;}
	}

	public float Range
	{
		get { return m_Range;}
		set { m_Range = value;}
	}
	#endregion

	#region private
	private DamageType m_DamageType;
	private int m_MinimalDamage, m_MaximalDamage;
	private float m_Range;
	#endregion
}
