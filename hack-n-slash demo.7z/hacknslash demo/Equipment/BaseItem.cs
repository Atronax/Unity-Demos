﻿using UnityEngine;
using System.Collections;

public class BaseItem 
{
	#region public 
	public enum RarityType {Common, Uncommon, Rare, Epic, Legendary};

	public BaseItem()
	{
		m_Name = "Noname";
		m_Rarity = RarityType.Common;
		m_CurrentDurability = m_MaximumDurability = 50;
		m_Value = 0;
	}

	public BaseItem(string Name, RarityType Rarity, int CurDurability, int MaxDurability, int Value)
	{
		m_Name = Name;
		m_Rarity = Rarity;
		m_MaximumDurability = MaxDurability;
		m_CurrentDurability = CurDurability;
		m_Value = Value;
	}

	// accessors
	public string Name
	{
		get { return m_Name;}
		set { m_Name = value;}
	}

	public RarityType Rarity
	{
		get { return m_Rarity;}
		set { m_Rarity = value;}
	}

	public int Value
	{
		get { return m_Value;}
		set { m_Value = Value;}
	}

	public int MaximumDurability
	{
		get { return m_MaximumDurability;}
		set { m_MaximumDurability = value;}
	}

	public int CurrentDurability
	{
		get { return m_CurrentDurability;}
		set { m_CurrentDurability = Value;}
	}
	#endregion

	#region private
	private string m_Name;

	private RarityType m_Rarity;
	private int m_CurrentDurability, m_MaximumDurability;
	private int m_Value;
	#endregion
}
