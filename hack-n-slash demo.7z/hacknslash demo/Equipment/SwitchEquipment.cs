using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;

public class SwitchEquipment : MonoBehaviour 
{
	void Start()
	{
		Initialize ();
	}

	void Update()
	{
		if (Input.GetKeyUp (KeyCode.Alpha1))
		{
			if (!HaveItemOfCategory("Leggings"))
				PutOn ("Leggings", "Silver Dragon Armor - Leggings");
			else
				TakeOff ("Leggings");
		}

		if (Input.GetKeyUp (KeyCode.Alpha2)) 
		{
			if (!HaveItemOfCategory("Boots"))
				PutOn ("Boots", "Silver Dragon Armor - Boots");
			else
				TakeOff ("Boots");
		}

		if (Input.GetKeyUp (KeyCode.Alpha3)) 
		{
			if (!HaveItemOfCategory("LeftGloves") && !HaveItemOfCategory("RightGloves"))
			{
				PutOn ("LeftGloves", "Left Glove - Berserker Plate");
				PutOn ("RightGloves", "Right Glove - Berserker Plate");
			}
			else
			{
				TakeOff ("LeftGloves");
				TakeOff ("RightGloves");
			}
		}

		if (Input.GetKeyUp (KeyCode.Alpha4)) 
		{
			if (!HaveItemOfCategory("Chests"))
				PutOn ("Chests", "Spellsword Armor - Cuirass");
			else
				TakeOff ("Chests");
		}

		if (Input.GetKeyUp (KeyCode.Alpha5)) 
		{
			if (!HaveItemOfCategory("Capes"))
				PutOn ("Capes", "Cape01");
			else
				TakeOff ("Capes");
		}
	}

	#region public
	public void PutOn (string Category, string ItemName)
	{
		GameObject ItemPrefab = GetItemPrefab (Category, ItemName);
		if (ItemPrefab)
		{
			// undress previous item of that category
			if (HaveItemOfCategory(Category))
				TakeOff(Category);

			// create a copy of prefab
			Hashtable CategoryItems = m_Items[Category] as Hashtable;
			CategoryItems["Current"] = Instantiate(ItemPrefab);
			
			// mark category cloth type as currently worn (to be able to wear only 1 piece of category)
			m_ItemsIsWorn[Category] = true;
			
			// here, boneObj must be instatiated and active (at least the one with the renderer), or else GetComponentsInChildren won't work.
			GameObject item = (GameObject)CategoryItems["Current"];
			SkinnedMeshRenderer[] BonedObjects = item.GetComponentsInChildren<SkinnedMeshRenderer>();
			foreach (SkinnedMeshRenderer smr in BonedObjects)
				ProcessBonedObject (item, smr); 	
		}
	}
	
	public void TakeOff(string Category)
	{
		if (HaveItemOfCategory (Category)) 
		{
			Destroy (GetItemPrefab(Category, "Current"));
			m_ItemsIsWorn [Category] = false;		
		}
	}	
	#endregion

	#region private	
	private void ProcessBonedObject (GameObject Item, SkinnedMeshRenderer SMRenderer)
	{
		// Set the gameobject with this script attached to as this boned object parent.
		Item.transform.parent = transform; 
		
		// Add the renderer to the current item.
		SkinnedMeshRenderer ItemSMRenderer = (SkinnedMeshRenderer) Item.AddComponent(typeof(SkinnedMeshRenderer)); 
		
		// Assemble bone structure. As clips are using bones by their names, we find them that way.
		Transform[] MyBones = new Transform [SMRenderer.bones.Length];
		for (int i = 0; i < SMRenderer.bones.Length; ++i)
			MyBones[i] = FindChildByName (SMRenderer.bones[i].name, transform);
		
		// Assemble skinned mesh renderer.	
		ItemSMRenderer.bones = MyBones;	
		ItemSMRenderer.sharedMesh = SMRenderer.sharedMesh;	
		ItemSMRenderer.materials = SMRenderer.materials;	
	}
	
	// Recursive search of the child by name.
	private Transform FindChildByName (string Name, Transform Object)	
	{		    
		if (Object.name == Name) // If the name match, we're return it.
			return Object.transform;	
		
		foreach (Transform child in Object) // Else, we go continue the search horizontally and vertically.
		{
			Transform Result = FindChildByName (Name, child);
			if (Result != null)	
				return Result;	
		}
		
		return null;	
	}	

	// Getters for simplified access to hashtables
	private GameObject GetItemPrefab (string Category, string Name)
	{
		GameObject Result = null;

		if (m_Items.Contains(Category))
		{
			Hashtable CategoryTable = m_Items [Category] as Hashtable;
			if (CategoryTable.Contains(Name))
				Result = CategoryTable[Name] as GameObject;			
		}

		return Result;
	}

	private bool HaveItemOfCategory (string Category)
	{
		return (bool)m_ItemsIsWorn [Category];
	}

	/// <summary> Initialize this instance. </summary>
	private void Initialize()
	{
		CreateItemsTables ();
		FillChests ();
		FillLeggings ();
		FillBoots ();
		FillLeftGloves ();
		FillRightGloves ();
		FillCapes ();
	}

	private void CreateItemsTables()
	{
		m_ItemsIsWorn = new Hashtable ();
		m_Items = new Hashtable ();
	}

	private void FillChests()
	{
		// add IsWorn initial boolean value for us to know if chest piece is currently worn or not
		m_ItemsIsWorn.Add ("Chests", false);

		// create hashtable to store all the chest prefabs, add all prefabs of chest pieces (in future may be replaced with Resource.Load)
		Hashtable Chests = new Hashtable();
		Chests.Add ("Current", null);
		Chests.Add ("Spellsword Armor - Cuirass", Resources.Load ("Equipment/Armor/Chests/SAC") as GameObject);

		// add this hashtable to m_Items collection
		m_Items.Add ("Chests", Chests);
	}

	private void FillLeggings()
	{
		m_ItemsIsWorn.Add ("Leggings", false);

		Hashtable Leggings = new Hashtable();
		Leggings.Add ("Current", null);
		Leggings.Add ("Silver Dragon Armor - Leggings", Resources.Load ("Equipment/Armor/Leggings/SDAL") as GameObject);

		m_Items.Add ("Leggings", Leggings);
	}

	private void FillBoots()
	{
		m_ItemsIsWorn.Add ("Boots", false);

		Hashtable Boots = new Hashtable ();
		Boots.Add ("Current", null);
		Boots.Add ("Silver Dragon Armor - Boots", Resources.Load ("Equipment/Armor/Boots/SDAB") as GameObject);

		m_Items.Add ("Boots", Boots);
	}

	private void FillLeftGloves()
	{
		m_ItemsIsWorn.Add ("LeftGloves", false);
		
		Hashtable LeftGloves = new Hashtable ();
		LeftGloves.Add ("Current", null);
		LeftGloves.Add ("Left Glove", Resources.Load ("Equipment/Armor/Gloves/LG") as GameObject);
		LeftGloves.Add ("Left Glove - Long", Resources.Load ("Equipment/Armor/Gloves/LG - Long") as GameObject);
		LeftGloves.Add ("Left Glove - Long Ringmetal", Resources.Load ("Equipment/Armor/Gloves/LG - Long Ringmetal") as GameObject);
		LeftGloves.Add ("Left Glove - Berserker", Resources.Load ("Equipment/Armor/Gloves/LG - Berserker") as GameObject);
		LeftGloves.Add ("Left Glove - Berserker Plate", Resources.Load ("Equipment/Armor/Gloves/LG - Berserker Plate") as GameObject);
		LeftGloves.Add ("Silver Dragon Armor - Left Glove", Resources.Load ("Equipment/Armor/Gloves/SDALG") as GameObject);
		
		m_Items.Add ("LeftGloves", LeftGloves);
	}

	private void FillRightGloves()
	{
		m_ItemsIsWorn.Add ("RightGloves", false);
		
		Hashtable RightGloves = new Hashtable ();
		RightGloves.Add ("Current", null);
		RightGloves.Add ("Right Glove", Resources.Load ("Equipment/Armor/Gloves/RG") as GameObject);
		RightGloves.Add ("Right Glove - Long", Resources.Load ("Equipment/Armor/Gloves/RG - Long") as GameObject);
		RightGloves.Add ("Right Glove - Long Ringmetal", Resources.Load ("Equipment/Armor/Gloves/RG - Long Ringmetal") as GameObject);
		RightGloves.Add ("Right Glove - Berserker", Resources.Load ("Equipment/Armor/Gloves/RG - Berserker") as GameObject);
		RightGloves.Add ("Right Glove - Berserker Plate", Resources.Load ("Equipment/Armor/Gloves/RG - Berserker Plate") as GameObject);
		RightGloves.Add ("Silver Dragon Armor - Right Glove", Resources.Load ("Equipment/Armor/Gloves/SDARG") as GameObject);
		
		m_Items.Add ("RightGloves", RightGloves);
	}

	private void FillCapes()
	{
		m_ItemsIsWorn.Add ("Capes", false);

		Hashtable Capes = new Hashtable ();
		Capes.Add ("Current", null);
		Capes.Add ("Cape01", Resources.Load ("Equipment/Armor/Capes/Cape01_Skinned") as GameObject);

		m_Items.Add ("Capes", Capes);
	}

	private Hashtable m_ItemsIsWorn, m_Items;
	#endregion
}
