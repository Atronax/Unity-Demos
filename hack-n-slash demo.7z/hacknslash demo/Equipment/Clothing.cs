﻿/// <summary>
/// Clothing.
/// September 30, 2015.
/// Author: Zamana Maxym.
/// 
/// Represents clothing logic of the games based on types and slots.
/// </summary>

using UnityEngine;

public class Clothing : BuffItem 
{
	#region public
	/// <summary>
	/// Stores collection of clothing slot types.
	/// </summary>
	public enum ClothingSlot 
	{ 
		Head, 
		LeftShoulder, RightShoulder, LeftSubShoulder, RightSubShoulder,
		LeftGlove, RightGlove,
		Torso,
		Leggings,
		Boots,
		Back
	}

	/// <summary>
	/// Initializes a new instance of the <see cref="Clothing"/> class with head slot.
	/// </summary>
	public Clothing()
	{
		m_Slot = ClothingSlot.Head;
	}

	/// <summary>
	/// Initializes a new instance of the <see cref="Clothing"/> class based on ClothingSlot param.
	/// </summary>
	/// <param name="Slot">Slot.</param>
	public Clothing(ClothingSlot Slot)
	{
		m_Slot = Slot;
	}

	/// <summary>
	/// ClothingSlot accessors: gets or sets the slot.
	/// </summary>
	/// <value>The slot.</value>
	public ClothingSlot Slot
	{
		get { return m_Slot;}
		set { m_Slot = value;}
	}

	#endregion

	#region private
	private ClothingSlot m_Slot;
	#endregion
}
