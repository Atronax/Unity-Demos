﻿/// <summary>
/// Jewellery.
/// September 30, 2015
/// Author: Zamana Maxym
/// 
/// Represents jewellery items through their types and slots.
/// </summary>

using UnityEngine;

public class Jewellery : BuffItem 
{
	#region public

	/// <summary>
	/// Stores collection of jewellery slot types.
	/// </summary>
	public enum JewellerySlot { Earrings, Necklaces, Bracelets, Rings, PocketItem }

	/// <summary>
	/// Initializes a new instance of the <see cref="Jewellery"/> class with base PocketItem value.
	/// </summary>
	public Jewellery()
	{
		m_Slot = JewellerySlot.PocketItem;
	}

	/// <summary>
	/// Initializes a new instance of the <see cref="Jewellery"/> class through param of JewellerySlot param.
	/// </summary>
	/// <param name="Slot">Slot.</param>
	public Jewellery(JewellerySlot Slot)
	{
		m_Slot = Slot;
	}

	/// <summary>
	/// JewellerySlot accessor: gets or sets the slot.
	/// </summary>
	/// <value>The slot.</value>
	public JewellerySlot Slot
	{
		get { return m_Slot; }
		set { m_Slot = value; }
	}
	#endregion

	#region private
	private JewellerySlot m_Slot;
	#endregion
}
