﻿using UnityEngine;
using System.Collections;

public class BuffItem : BaseItem 
{
	#region public
	public BuffItem()
	{
		m_Buffs = new Hashtable ();
	}

	public BuffItem(Hashtable Buffs)
	{
		m_Buffs = Buffs;
	}

	public void AddBuff (BaseStat Stat, int Value)
	{
		m_Buffs.Add (Stat.Name, Value);
	}

	public void RemoveBuff (BaseStat Stat)
	{
		m_Buffs.Remove (Stat.Name);
	}

	public int BuffCount ()
	{
		return m_Buffs.Count;
	}

	public Hashtable Buffs
	{
		get { return m_Buffs;}
	}
	#endregion

	#region private
	private Hashtable m_Buffs;
	#endregion
}
