﻿using UnityEngine;
using System.Linq;
using System.Collections;
using System.Collections.Generic;


public class MobGenerator : MonoBehaviour {

	// Use this for initialization
	void Awake ()
	{
		m_State = MobGeneratorState.Initializing;
	}

	void Start () {

	}
	
	// Update is called once per frame
	void Update () {
		switch (m_State) 
		{
		case MobGeneratorState.Initializing:
			Initialize ();
			break;

		case MobGeneratorState.Setupping:
			Setup ();
			break;

		case MobGeneratorState.Idling:
			break;

		case MobGeneratorState.Spawning:
			Spawn ();
			break;
		}
	}

	#region public
	public GameObject[] m_MobPrefabs; // holds mobs prefabs we want to spawn
	public GameObject[] m_MobSpawnPoints; // holds mobs spawn points where we want to spawn enemies
	#endregion

	#region private
	private void Initialize()
	{
		Debug.Log ("Initialize function");
		if (!m_MobPrefabs.Any() || !m_MobSpawnPoints.Any())
			return;

		m_State = MobGeneratorState.Setupping;
	}

	private void Setup()
	{
		Debug.Log ("Setup function");

		m_State = MobGeneratorState.Spawning;
	}

	private void Spawn()
	{
		Debug.Log ("Spawn function");

		GameObject[] AvailableSpawnpoints = EmptySpawnpoints ();
		foreach (GameObject Spawnpoint in AvailableSpawnpoints)
		{
			// get random enemy prefab from the list of available enemies
			int EnemyIndex = Random.Range(0, m_MobPrefabs.Length);

			// instantiate an enemy, set it a child of spawnpoint
			GameObject Enemy = (GameObject)Instantiate(m_MobPrefabs[EnemyIndex], Spawnpoint.transform.position, Spawnpoint.transform.rotation);
			Enemy.transform.SetParent(Spawnpoint.transform);

			// append it to the targetting system
			TargettingSystem Targetting = GameObject.Find("Game Master").GetComponent<TargettingSystem>();
			Targetting.PushOneEnemy(Enemy);

		}

		m_State = MobGeneratorState.Idling;
	}

	private GameObject[] EmptySpawnpoints()
	{
		List<GameObject> Result = new List<GameObject>();

		foreach (GameObject SpawnPoint in m_MobSpawnPoints) 
		{
			if (SpawnPoint.transform.childCount == 0) 
			{
				Debug.Log ("Spawn Point Available");
				Result.Add (SpawnPoint);
			}
		}		

		return Result.ToArray();
	}

	/// <summary> Mob Generator state machine, that controls workflow of enemies spawning and respawning. </summary>
	private enum MobGeneratorState
	{
		Initializing,
		Setupping,
		Idling,
		Spawning
	}

	private MobGeneratorState m_State;
	#endregion
}
