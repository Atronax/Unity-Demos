using System.Collections;
using UnityEngine;

public class OrbitCam: MonoBehaviour 
{	
	#region public
	public void Start() 
	{
		Vector3 angles = transform.eulerAngles;
		x_angle = angles.y;
		y_angle = angles.x;
	}
	
	public void LateUpdate() 
	{
		if (m_Target) 
		{
			// поворот камеры
			x_angle += Input.GetAxis("Mouse X") * xSpeed * distance * 0.02f;
			y_angle -= Input.GetAxis("Mouse Y") * ySpeed * 0.02f;			
			y_angle = ClampAngle(y_angle, yMinLimit, yMaxLimit);												
			Quaternion rotation = Quaternion.Euler(y_angle, x_angle, 0);

			// расстояние камеры от игрока
			distance = Mathf.Clamp(distance - Input.GetAxis("Mouse ScrollWheel")*distanceSpd, distanceMin, distanceMax);
			
			RaycastHit hit;
			if (Physics.Linecast (m_Target.position, transform.position, out hit)) 
				distance -=  hit.distance;

			// позиция камеры 
			Vector3 negDistance = new Vector3(0.0f, 0.0f, -distance);
			Vector3 position = rotation * negDistance + m_Target.position;

			// применяем результаты вычислений						
			transform.rotation = rotation;
			transform.position = position;
		}
	}
	
	public static float ClampAngle(float angle, float min, float max)
	{
		if (angle < -360F)
			angle += 360F;
		if (angle > 360F)
			angle -= 360F;
		return Mathf.Clamp(angle, min, max);
	}

	// accessors
	public Transform Target
	{
		get { return m_Target;}
		set { m_Target = value;}
	}

	[SerializeField] public Transform m_Target;
	#endregion public

	#region private	
	// in game mode
	[SerializeField] private float x_angle = 0.0f;
	[SerializeField] private float y_angle = 0.0f;
	[SerializeField] private float distance = 5.0f;

	// in editor mode
	[SerializeField] private float xSpeed = 120.0f;
	[SerializeField] private float ySpeed = 120.0f;
	
	[SerializeField] private float yMinLimit = -20.0f;
	[SerializeField] private float yMaxLimit = 80.0f;
	
	[SerializeField] [Range(1f, 100f)] private float distanceSpd = 5;
	[SerializeField] private float distanceMin = 0.5f;
	[SerializeField] private float distanceMax = 15.0f;
	#endregion private
}
