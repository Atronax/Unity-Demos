﻿using UnityEngine;
using System.Collections;

/// <summary>
/// For this camera to work properly, we will need to make sure the following objects exist in the INPUT MANAGER:
/// - rotate camera button (the button we will press to allow us to rotate the camera)
/// - mouse x axis (rotate the camera horizontally with a mouse)
/// - mouse y axis (rotate the camera vertically with a mouse)
/// - keyboard x button (rotate the camera horizontally with a keyboard)
/// - keyboard y button (rotate the camera vertically with a keyboard)
/// - reset camera position button
/// </summary>
public class HNSCam : MonoBehaviour 
{
	#region public

	public void Start () 
	{
		InitializeVariables ();
	}

	public void Update ()
	{
		m_RotationKeyboardButtonsPressed = Input.GetButton ("Rotate Camera Horizontally Key") || Input.GetButton ("Rotate Camera Vertically Key");
		m_RotationMouseButtonsPressed = Input.GetButton ("Rotate Camera Button");
	}

	// called after every single update function
	public void LateUpdate ()
	{
		if (m_RotationKeyboardButtonsPressed || m_RotationMouseButtonsPressed) 
			UpdateCameraRotation ();	
		else
			UpdateCameraPosition ();
	}

	public Transform m_TargetTransform;
	public float m_WalkDistance, m_RunDistance;	
	public float m_CameraXRotationSpeed, m_CameraYRotationSpeed; 
	public float m_CameraXRotationDamping, m_CameraYRotationDamping;
	public float m_CameraHeight;
	#endregion

	#region private 	 
	private void InitializeVariables()
	{
		// caching transform component of camera
		m_CameraTransform = transform; 

		// setting up all variables needed by cameras orbit part
		m_CameraXRotationSpeed = 250.0f;
		m_CameraYRotationSpeed = 120.0f;
		m_CameraXRotationDamping = 2.0f;
		m_CameraYRotationDamping = 5.0f;
	}

	/// <summary>
	/// Updates the camera rotation. 
	/// The ability to rotate the camera around target.
	/// </summary>
	private void UpdateCameraRotation()
	{
		if (m_RotationKeyboardButtonsPressed) 
		{
			m_XRotation += Input.GetAxis ("Rotate Camera Horizontally Key") * m_CameraXRotationSpeed * 0.02f;
			m_YRotation -= Input.GetAxis ("Rotate Camera Vertically Key") * m_CameraYRotationSpeed * 0.02f;
			
			Debug.Log("Rotation Keyboard Buttons Are Pressed");
		}
		else if (m_RotationMouseButtonsPressed) 
		{
			m_XRotation += Input.GetAxis ("Mouse X") * m_CameraXRotationSpeed * 0.02f;
			m_YRotation -= Input.GetAxis ("Mouse Y") * m_CameraYRotationSpeed * 0.02f;

			Debug.Log("Rotation Mouse Buttons Are Pressed");
		}		 
		
		Quaternion Rotation = Quaternion.Euler (m_YRotation, m_XRotation, 0.0f);
		Vector3 Position = Rotation * new Vector3 (0.0f, 0.0f, -m_WalkDistance) + m_TargetTransform.position;
		
		m_CameraTransform.rotation = Rotation;
		m_CameraTransform.position = Position;	
	}

	/// <summary>
	/// Updates the camera position.
	/// The effect of cameras' swaying behind the target.
	/// </summary>
	private void UpdateCameraPosition()
	{
		// reinitialize cameras rotation component
		m_XRotation = m_YRotation = 0.0f;

		// wanted and current value of cameras rotation angle (y part)
		float WantedAngleY = m_TargetTransform.eulerAngles.y;
		float CurrentAngleY = m_CameraTransform.eulerAngles.y;

		// wanted and current value of cameras height above targets position
		float WantedHeight = m_TargetTransform.position.y + m_CameraHeight;
		float CurrentHeight = m_CameraTransform.position.y;

		// effect of Y-axis angle and height damping. We can add more vars to interpolate them between angles of 0-360d or float values.
		CurrentAngleY = Mathf.LerpAngle (CurrentAngleY, WantedAngleY, m_CameraXRotationDamping * Time.deltaTime);
		CurrentHeight = Mathf.Lerp (CurrentHeight, WantedHeight, m_CameraYRotationDamping * Time.deltaTime);

		// convert from euler angles to quaternion rotation view
		Quaternion CurrentRotation = Quaternion.Euler (0, CurrentAngleY, 0);

		// set the camera position behind the target on distance equal to m_WalkDistance 
		m_CameraTransform.position = m_TargetTransform.position - CurrentRotation * Vector3.forward * m_WalkDistance;
		m_CameraTransform.position = new Vector3 (m_CameraTransform.position.x, CurrentHeight, m_CameraTransform.position.z);
		m_CameraTransform.LookAt (m_TargetTransform);
	}

	// cameras and targets transform components
	private Transform m_CameraTransform; 

	// cameras orbit rotation part
	private float m_XRotation, m_YRotation;
	private bool m_RotationKeyboardButtonsPressed, m_RotationMouseButtonsPressed;
	#endregion
}