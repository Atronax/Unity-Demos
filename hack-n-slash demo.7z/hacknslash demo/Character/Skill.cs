﻿/// <summary>
/// Skill.
/// August 19, 2015
/// Max Zamana
/// 
/// Represents a set of player skills. 
/// </summary>

using System.Collections.Generic;

/// <summary> Skill type. <para>   </para> You can add your own here, if you wish, but you will need to setup modifiers for them in Base Character class. </summary>
public enum SkillType
{
	Melee_Offence,
	Melee_Defence,
	Ranged_Offence,
	Ranged_Defence,
	Magic_Offence,
	Magic_Defence,
	Critical_Attack,
	Critical_Chance,
	Speed,
	Trade
}

public class Skill : ModifiedStat
{
	#region public
	/// <summary> Initializes a new instance of the <see cref="Skill"/> class. </summary>
	public Skill()
	{
		SetupTranslation ();

		m_IsKnown = false;
		ExperienceToNextLevel = 25;
		ExperienceToNextLevelModifier = 1.1f;
	}

	/// <summary> Gets or sets a value indicating whether this skill is known. </summary>
	/// <value><c>true</c> if this skill is known; otherwise, <c>false</c>.</value>
	public bool IsKnown
	{
		get{return m_IsKnown;}
		set{m_IsKnown = value;}
	}

	/// <summary> Gets the translation of vitality type string, written as a parameter. </summary>
	/// <returns>The translation of parameter string.</returns>
	/// <param name="str">Parameter string.</param>
	public string GetTranslationOf (string str)
	{
		return m_Translation[str];
	}
	#endregion

	#region private
	/// <summary> Setups the translation dictionary. </summary>
	private void SetupTranslation()
	{
		m_Translation = new SortedDictionary<string, string> ();
		m_Translation.Add("Melee_Offence", "Ближний бой - атака");
		m_Translation.Add("Melee_Defence", "Ближний бой - защита");
		m_Translation.Add("Ranged_Offence", "Дальний бой - атака");
		m_Translation.Add("Ranged_Defence", "Дальний бой - защита");
		m_Translation.Add("Magic_Offence", "Магия - атака");
		m_Translation.Add("Magic_Defence", "Магия - защита");
		m_Translation.Add("Critical_Attack", "Урон критического удара");
		m_Translation.Add("Critical_Chance", "Шанс критического удара");
		m_Translation.Add("Speed", "Скорость");
		m_Translation.Add("Trade", "Торговля");
	}	
	
	private static SortedDictionary<string, string> m_Translation;
	private bool m_IsKnown;
	#endregion
}
