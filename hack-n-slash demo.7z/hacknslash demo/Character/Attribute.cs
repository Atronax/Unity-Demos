﻿/// <summary>
/// Attribute type.
/// August 16, 2015
/// Max Zamana
/// 
/// Represents all of the characters attributes.
/// </summary>

using System.Collections.Generic;

/// <summary>
/// Attribute type enumeration.
/// You can add or replace anything you want, but do not forget you need to setup modifiers
/// for types you set in BaseCharacter class and delete modifiers for those types, that
/// you have deleted.
/// </summary>
public enum AttributeType
{
	Strength,
	Agility,
	Endurance,
	Intellect,
	Willpower,
	Luck,
	Charisma,
	Perception
}

public class Attribute : BaseStat
{
	#region public
	/// <summary>
	/// Initializes a new instance of the <see cref="Attribute"/> class.
	/// </summary>
	public Attribute()
	{
		SetupTranslation ();

		ExperienceToNextLevel = 50;
		ExperienceToNextLevelModifier = 1.05f;
	}

	/// <summary>
	/// Gets the translation of string, passed to this function in param.
	/// </summary>
	/// <returns>The translation of param string.</returns>
	/// <param name="str">String you need to translate.</param>
	public string GetTranslationOf (string str)
	{
		return m_Translation[str];
	}

	new public const int StartingExperienceCost = 50; // c# variable override
	#endregion

	#region private
	/// <summary>
	/// Setups the translation.
	/// </summary>
	private void SetupTranslation()
	{
		m_Translation = new SortedDictionary<string, string> ();
		m_Translation.Add("Strength", "Сила");
		m_Translation.Add("Agility", "Ловкость");
		m_Translation.Add("Endurance", "Выносливость");
		m_Translation.Add("Intellect", "Интеллект");
		m_Translation.Add("Willpower", "Воля");
		m_Translation.Add("Luck", "Удача");
		m_Translation.Add("Charisma", "Харизма");
		m_Translation.Add("Perception", "Восприятие");
	}

	private static SortedDictionary<string, string> m_Translation;
	#endregion
}
