﻿using UnityEngine;
using System.Collections;
using System; // to access enum class

public class BaseCharacter : MonoBehaviour
{
	#region public
	public void Awake() 
	{
		Debug.Log ("in basecharacter awake");
		m_Name = string.Empty;
		m_Level = 0;
		m_FreeExperience = 0;
				
		SetupAttributes ();
		SetupVitalities ();
		SetupSkills ();
	}

	// Accessors
	public string Name
	{
		get { return m_Name;}
		set { m_Name = value;}
	}

	public int Level
	{
		get { return m_Level;}
		set { m_Level = value;}
	}

	public uint FreeExperience
	{
		get { return m_FreeExperience;}
		set { m_FreeExperience = value;}
	}

	// Statistics control
	public Attribute GetAttribute(int index)
	{
		return m_Attributes[index];
	}

	public Vitality GetVitality(int index)
	{
		return m_Vitalities[index];
	}

	public Skill GetSkill(int index)
	{
		return m_Skills[index];
	}

	// Level control
	public void AddExperience (uint exp)
	{
		m_FreeExperience += exp;

		CalculateLevel();
	}

	public void CalculateLevel()
	{
		// take average of all the players attributes and assign that as a player level
		int TotalAttributePoints = 0;
		foreach (Attribute attr in m_Attributes)
			TotalAttributePoints += attr.Base;

		m_Level = TotalAttributePoints / m_Attributes.Length;
	}

	// Update
	public void UpdateStats()
	{
		for (int i = 0; i < m_Vitalities.Length; ++i)
			m_Vitalities[i].Update();

		for (int i = 0; i < m_Skills.Length; ++i)
			m_Skills[i].Update();
	}
	#endregion

	#region private
	private void SetupAttributes()
	{
		m_Attributes = new Attribute[Enum.GetValues(typeof(AttributeType)).Length];
		for (int i = 0; i < m_Attributes.Length; ++i) {
			m_Attributes [i] = new Attribute ();
			m_Attributes [i].Name = ((AttributeType)i).ToString();
		}
	}

	private void SetupVitalities()
	{
		m_Vitalities = new Vitality[Enum.GetValues(typeof(VitalityType)).Length];
		for (int i = 0; i < m_Vitalities.Length; ++i)		
			m_Vitalities[i] = new Vitality();

		SetupVitalitiesModifiers();
	}

	private void SetupSkills()
	{
		m_Skills = new Skill[Enum.GetValues(typeof(SkillType)).Length];
		for (int i = 0; i < m_Skills.Length; ++i)		
			m_Skills[i] = new Skill();

		SetupSkillsModifiers();
	}

	private void SetupVitalitiesModifiers()
	{
		// Health
		GetVitality ((int)VitalityType.Health).AddModifier(new ModifyingAttribute(GetAttribute((int)AttributeType.Endurance), 2.0f));
		GetVitality ((int)VitalityType.Health).AddModifier(new ModifyingAttribute(GetAttribute((int)AttributeType.Strength), 1.0f));

		// Energy
		GetVitality ((int)VitalityType.Energy).AddModifier(new ModifyingAttribute(GetAttribute((int)AttributeType.Agility), 2.0f));
		GetVitality ((int)VitalityType.Energy).AddModifier(new ModifyingAttribute(GetAttribute((int)AttributeType.Endurance), 1.0f));

		// Mana
		GetVitality ((int)VitalityType.Mana).AddModifier(new ModifyingAttribute(GetAttribute((int)AttributeType.Willpower), 2.0f));
		GetVitality ((int)VitalityType.Mana).AddModifier(new ModifyingAttribute(GetAttribute((int)AttributeType.Intellect), 1.0f));

		// Rage
		GetVitality ((int)VitalityType.Rage).AddModifier(new ModifyingAttribute(GetAttribute((int)AttributeType.Strength), 2.0f));
		GetVitality ((int)VitalityType.Rage).AddModifier(new ModifyingAttribute(GetAttribute((int)AttributeType.Endurance), 1.0f));
	}

	private void SetupSkillsModifiers()
	{
		// Melee Offence
		GetSkill((int)SkillType.Melee_Offence).AddModifier(new ModifyingAttribute(GetAttribute((int)AttributeType.Strength), 2.0f));
		GetSkill((int)SkillType.Melee_Offence).AddModifier(new ModifyingAttribute(GetAttribute((int)AttributeType.Agility), 1.0f));

		// Melee Defence
		GetSkill((int)SkillType.Melee_Defence).AddModifier(new ModifyingAttribute(GetAttribute((int)AttributeType.Endurance), 2.0f));
		GetSkill((int)SkillType.Melee_Defence).AddModifier(new ModifyingAttribute(GetAttribute((int)AttributeType.Strength), 1.0f));

		// Range Offence
		GetSkill((int)SkillType.Ranged_Offence).AddModifier(new ModifyingAttribute(GetAttribute((int)AttributeType.Agility), 2.0f));
		GetSkill((int)SkillType.Ranged_Offence).AddModifier(new ModifyingAttribute(GetAttribute((int)AttributeType.Perception), 1.0f));

		// Range Defence
		GetSkill((int)SkillType.Ranged_Defence).AddModifier(new ModifyingAttribute(GetAttribute((int)AttributeType.Perception), 2.0f));
		GetSkill((int)SkillType.Ranged_Defence).AddModifier(new ModifyingAttribute(GetAttribute((int)AttributeType.Endurance), 1.0f));

		// Magic Offence
		GetSkill((int)SkillType.Magic_Offence).AddModifier(new ModifyingAttribute(GetAttribute((int)AttributeType.Intellect), 2.0f));
		GetSkill((int)SkillType.Magic_Offence).AddModifier(new ModifyingAttribute(GetAttribute((int)AttributeType.Willpower), 1.0f));

		// Magic Defence
		GetSkill((int)SkillType.Magic_Defence).AddModifier(new ModifyingAttribute(GetAttribute((int)AttributeType.Willpower), 2.0f));
		GetSkill((int)SkillType.Magic_Defence).AddModifier(new ModifyingAttribute(GetAttribute((int)AttributeType.Perception), 1.0f));

		// Critical Attack
		GetSkill((int)SkillType.Critical_Attack).AddModifier(new ModifyingAttribute(GetAttribute((int)AttributeType.Agility), 2.0f));
		GetSkill((int)SkillType.Critical_Attack).AddModifier(new ModifyingAttribute(GetAttribute((int)AttributeType.Strength), 1.0f));

		// Critical Chance
		GetSkill((int)SkillType.Critical_Chance).AddModifier(new ModifyingAttribute(GetAttribute((int)AttributeType.Agility), 0.2f));
		GetSkill((int)SkillType.Critical_Chance).AddModifier(new ModifyingAttribute(GetAttribute((int)AttributeType.Luck), 0.1f));

		// Speed
		GetSkill((int)SkillType.Speed).AddModifier(new ModifyingAttribute(GetAttribute((int)AttributeType.Agility), 2.0f));
		GetSkill((int)SkillType.Speed).AddModifier(new ModifyingAttribute(GetAttribute((int)AttributeType.Endurance), 1.0f));

		// Trade
		GetSkill((int)SkillType.Trade).AddModifier(new ModifyingAttribute(GetAttribute((int)AttributeType.Charisma), 2.0f));
		GetSkill((int)SkillType.Trade).AddModifier(new ModifyingAttribute(GetAttribute((int)AttributeType.Luck), 1.0f));
	}

	private string m_Name;
	private int m_Level;
	private uint m_FreeExperience;

	public Attribute[] m_Attributes;
	public Vitality[] m_Vitalities;
	public Skill[] m_Skills;
	#endregion
}
