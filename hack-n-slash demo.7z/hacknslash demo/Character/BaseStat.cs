﻿/// <summary>
/// Base stat.
/// Max Zamana
/// August 15, 2015
/// 
/// Base class for stats in game.
/// </summary>

public class BaseStat
{
	#region public
	/// <summary>
	/// Initializes a new instance of the <see cref="BaseStat"/> class.
	/// </summary>
	public BaseStat()
	{
		m_Name = "";
		m_Base = 0;
		m_Buff = 0;
		m_Debuff = 0;
		m_ExperienceToNextLevel = StartingExperienceCost;
		m_ExperienceToNextLevelModifier = StartingExperienceMod;
	}

	/// <summary>
	/// Gets or sets the name.
	/// </summary>
	/// <value>The name.</value>
	public string Name
	{
		get { return m_Name;}
		set { m_Name = value;}
	}

	/// <summary>
	/// Gets or sets the base value for this stat.
	/// </summary>
	/// <value>The base.</value>
	public int Base
	{
		get{return m_Base;}
		set{m_Base = value;}
	}

	/// <summary>
	/// Gets or sets the buff value for this stat.
	/// </summary>
	/// <value>The buff.</value>
	public int Buff
	{
		get{return m_Buff;}
		set{m_Buff = value;}
	}

	/// <summary>
	/// Gets or sets the debuff value for this stat.
	/// </summary>
	/// <value>The debuff.</value>
	public int Debuff
	{
		get{return m_Debuff;}
		set{m_Debuff = value;}
	}

	/// <summary>
	/// Gets or sets the needed experience to next level.
	/// </summary>
	/// <value>The experience to next level.</value>
	public int ExperienceToNextLevel
	{
		get{return m_ExperienceToNextLevel;}
		set{m_ExperienceToNextLevel = value;}
	}

	/// <summary>
	/// Gets or sets the experience to next level modifier.
	/// </summary>
	/// <value>The experience to next level modifier.</value>
	public float ExperienceToNextLevelModifier
	{
		get{return m_ExperienceToNextLevelModifier;}
		set{m_ExperienceToNextLevelModifier = value;}
	}
	
	/// <summary>
	/// Gets the adjusted base value of stat (base + buff - debuff).
	/// </summary>
	/// <value>The total.</value>
	public int Total
	{
		get { return m_Base + m_Buff - m_Debuff;}
	}

	/// <summary>
	/// Calculates new base value and modifiers values. Levels up.
	/// </summary>
	public void LevelUp()
	{
		// m_ExperienceToNextLevelModifier *= 1.5f;

		++m_Base;
		m_ExperienceToNextLevel = CalculateExperienceToNextLevel();
	}

	public const int StartingExperienceCost = 100;
	public const float StartingExperienceMod = 1.1f;
	#endregion

	#region private
	/// <summary>
	/// Calculates the experience to next level.
	/// </summary>
	/// <returns>The experience to next level.</returns>
	private int CalculateExperienceToNextLevel()
	{
		return (int)(m_ExperienceToNextLevel*m_ExperienceToNextLevelModifier);
	}

	// Variables
	private string m_Name;
	private int m_Base;
	private int m_Buff;
	private int m_Debuff;
	private int m_ExperienceToNextLevel;
	private float m_ExperienceToNextLevelModifier;
	#endregion
}