﻿public class PlayerCharacter : BaseCharacter 
{
	void Start()
	{
		UpdateHealthbar ();
		UpdateManabar ();
	}

	void Update()
	{
	}

	#region public
	public void UpdateHealthbar()
	{
		Messenger<int,int>.Broadcast ("Player Health has changed", GetVitality ((int)VitalityType.Health).Current, GetVitality ((int)VitalityType.Health).Total);
	}

	public void UpdateManabar()
	{
		Messenger<int,int>.Broadcast ("Player Mana has changed", GetVitality ((int)VitalityType.Mana).Current, GetVitality ((int)VitalityType.Mana).Total);
	}

	public void UpdateEnergybar()
	{
		Messenger<int,int>.Broadcast ("Player Energy has changed", GetVitality ((int)VitalityType.Energy).Current, GetVitality ((int)VitalityType.Energy).Total);
	}

	public void UpdateRagebar()
	{
		Messenger<int,int>.Broadcast ("Player Rage has changed", GetVitality ((int)VitalityType.Rage).Current, GetVitality ((int)VitalityType.Rage).Total);
	}

	#endregion

	#region private
	#endregion
}
