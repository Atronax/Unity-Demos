﻿using UnityEngine;
using System.Collections;
using System; // for enum

public class MobCharacter : BaseCharacter
{
	// Use this for initialization
	void Start () 
	{
		// TEST CODE. Later we will need to randomly set its attribute

		// set endurance attribute, update health and set current vitalities value to maximum
		// GetAttribute ((int)AttributeType.Endurance).Base = 100; // 1
		// GetVitality ((int)VitalityType.Health).Update (); // 2
		// for (int i = 0; i < Enum.GetValues(typeof(VitalityType)).Length; ++i) // 3
			// GetVitality(i).Current = GetVitality(i).Total;
	}
	
	// Update is called once per frame
	void Update () 
	{

	}

	#region public
	public void DisplayHealth()
	{
		Messenger<int,int>.Broadcast ("Target Health has changed", m_CurrentHealth, m_MaximumHealth);
	}

	public int m_CurrentHealth;
	public int m_MaximumHealth;
	#endregion

	#region private
	#endregion
}
