﻿using UnityEngine;
using System.Collections;
using System;

public class CharacterGenerator : MonoBehaviour 
{
	// Use this for initialization
	void Start () 
	{
		CreateCharacter ();
		InitializeWidgetsSizes ();
		GenerateStartingAttributes ();
	}
	
	// Update is called once per frame
	void Update () 
	{
	}

	void OnGUI () 
	{
		// Skin
		GUI.skin = m_GeneratorSkin;
		GUI.Box (new Rect (0, 0, Screen.width, Screen.height), "");
		
		DisplayName ();
		DisplayPointsLeft ();
		DisplayAttributes ();
		DisplayVitalities ();
		DisplaySkills ();

		if (m_PointsLeft == 0 && m_Player.Name.Length > 2)
			DisplayCreateButtonOn ();
		else
			DisplayCreateButtonOff ();
	}

	#region public
	// Skin
	public GUISkin m_GeneratorSkin;

	// Player
	public GameObject m_PlayerPrefab;
	#endregion

	#region private
	// Sizes of widgets
	private void InitializeWidgetsSizes()
	{
		Offset = 10;

		SmallBlockWidth = 30;
		PreMediumBlockWidth = 100;
		MediumBlockWidth = 150;
		LargeBlockWidth = 250;

		BlockHeight = 25;
		BlockInterval = 1;

		NamePositionX = (int)((Screen.width - (MediumBlockWidth + LargeBlockWidth)) / 2.0f);
		PointsPositionX = 10;
		AttributesPositionX = 10;
		VitalitiesPositionX = (int)((Screen.width - (PreMediumBlockWidth + Offset + SmallBlockWidth)) / 2.0f);
		SkillsPositionX = (int)(Screen.width - (LargeBlockWidth + SmallBlockWidth + 2*Offset));
		CreateButtonPositionX = (int)((Screen.width - MediumBlockWidth) / 2.0f);

		NamePositionY = 10;
		PointsPositionY = 10;
		AttributesPositionY = 60;
		VitalitiesPositionY = 60;
		SkillsPositionY = 60;
		CreateButtonPositionY = Screen.height - 30;
	}

	private int NamePositionX, PointsPositionX, AttributesPositionX, VitalitiesPositionX, SkillsPositionX, CreateButtonPositionX;
	private int NamePositionY, PointsPositionY, AttributesPositionY, VitalitiesPositionY, SkillsPositionY, CreateButtonPositionY;
	private int SmallBlockWidth, PreMediumBlockWidth, MediumBlockWidth, LargeBlockWidth;
	private int BlockHeight, BlockInterval;
	private int Offset;

	// Display GUI
	private void DisplayName()
	{
		GUI.Label (new Rect (NamePositionX, NamePositionY, MediumBlockWidth, BlockHeight), "Имя: ");
		m_Player.Name = GUI.TextField (new Rect (NamePositionX + MediumBlockWidth + Offset, NamePositionY, LargeBlockWidth, BlockHeight), m_Player.Name);
	}

	private void DisplayPointsLeft()
	{
		GUI.Label (new Rect (PointsPositionX, PointsPositionY, MediumBlockWidth, BlockHeight), "Осталось: " + m_PointsLeft.ToString());
	}

	private void DisplayAttributes()
	{
		for (int i = 0; i < Enum.GetValues(typeof(AttributeType)).Length; ++i)
		{
			GUI.Label(new Rect(AttributesPositionX, AttributesPositionY + (BlockHeight + BlockInterval)*i, MediumBlockWidth, BlockHeight), m_Player.GetAttribute(i).GetTranslationOf(((AttributeType)i).ToString()));
			GUI.Label(new Rect(AttributesPositionX + MediumBlockWidth + Offset, AttributesPositionY + (BlockHeight + BlockInterval)*i, SmallBlockWidth, BlockHeight), m_Player.GetAttribute(i).Total.ToString());

			// Controls
			bool AttributePlusPressed = GUI.Button(new Rect(AttributesPositionX + MediumBlockWidth + Offset + SmallBlockWidth + Offset, AttributesPositionY +(BlockHeight + BlockInterval)*i, SmallBlockWidth, BlockHeight), "+");
			bool AttributeMinusPressed = GUI.Button(new Rect(AttributesPositionX + MediumBlockWidth + Offset + 2*(SmallBlockWidth + Offset), AttributesPositionY +(BlockHeight + BlockInterval)*i, SmallBlockWidth, BlockHeight), "-");

			if (AttributePlusPressed)
				ResolveAttributePlus(i);
			if (AttributeMinusPressed)	
				ResolveAttributeMinus(i);
		}
	}

	private void ResolveAttributePlus(int attribute_index)
	{
		if (m_PointsLeft > 0) // if we have points left
		{
			if (Input.GetKey(KeyCode.LeftShift) && m_Player.GetAttribute(attribute_index).Base + 10 <= 100) // Increase by 10
			{
				m_Player.GetAttribute(attribute_index).Base += (m_PointsLeft < 10) ? m_PointsLeft : 10;
				m_PointsLeft -= (m_PointsLeft < 10) ? m_PointsLeft : 10;
			}
			else if (m_Player.GetAttribute(attribute_index).Base < 100) // Increase by 1
			{
				++m_Player.GetAttribute(attribute_index).Base;
				--m_PointsLeft;
			}

			m_Player.UpdateStats ();
		}
	}

	private void ResolveAttributeMinus(int attribute_index)
	{
		if (Input.GetKey(KeyCode.LeftShift) && m_Player.GetAttribute(attribute_index).Base - 10 >= m_StartingMinimum)
		{
			m_Player.GetAttribute(attribute_index).Base -= 10;
			m_PointsLeft += 10;
		}
		else if (m_Player.GetAttribute(attribute_index).Base > m_StartingMinimum)
		{
			--m_Player.GetAttribute(attribute_index).Base;
			++m_PointsLeft;
		}

		m_Player.UpdateStats ();
	}

	private void DisplayVitalities()
	{
		for (int i = 0; i < Enum.GetValues(typeof(VitalityType)).Length; ++i) 
		{
			GUI.Label(new Rect(VitalitiesPositionX, VitalitiesPositionY + (BlockHeight + BlockInterval)*i, PreMediumBlockWidth, BlockHeight), m_Player.GetVitality(i).GetTranslationOf(((VitalityType)i).ToString()));
			GUI.Label(new Rect(VitalitiesPositionX + PreMediumBlockWidth + Offset, VitalitiesPositionY + (BlockHeight + BlockInterval)*i,  SmallBlockWidth, BlockHeight), m_Player.GetVitality(i).Total.ToString());
		}
	}

	private void DisplaySkills()
	{
		for (int i = 0; i < Enum.GetValues(typeof(SkillType)).Length; ++i)
		{
			GUI.Label(new Rect(SkillsPositionX, SkillsPositionY + (BlockHeight + BlockInterval)*i, LargeBlockWidth, BlockHeight), m_Player.GetSkill(i).GetTranslationOf(((SkillType)i).ToString()));
			GUI.Label(new Rect(SkillsPositionX + LargeBlockWidth + Offset, SkillsPositionY + (BlockHeight + BlockInterval)*i,  SmallBlockWidth, BlockHeight), m_Player.GetSkill(i).Total.ToString());
		}
	}

	private void DisplayCreateButtonOn()
	{
		bool CreatePressed = GUI.Button (new Rect (CreateButtonPositionX, CreateButtonPositionY, MediumBlockWidth, BlockHeight), "Создать");
		if (CreatePressed) 
		{	
			GameSettings GameSettings = GameObject.Find("Settings").GetComponent<GameSettings>();

			UpdateVitalitiesCurrentValues();
			GameSettings.SaveCharacterData();

			Application.LoadLevel("Level1");
		}
	}

	private void DisplayCreateButtonOff()
	{
		GUI.Label (new Rect (CreateButtonPositionX, CreateButtonPositionY, LargeBlockWidth, BlockHeight), "Настройте персонажа");
	}

	// Level points
	private void GenerateStartingAttributes()
	{
		// initialization
		m_PointsLeft = m_StartingPoints;
		for (int i = 0; i < Enum.GetValues(typeof(AttributeType)).Length; ++i)
			m_Player.GetAttribute(i).Base = m_StartingMinimum;

		// standard attribute set
		for (int i = 0; i < Enum.GetValues(typeof(AttributeType)).Length; ++i) 
		{
			m_Player.GetAttribute(i).Base += 40;
			m_PointsLeft -= 40;
		}

		// update stats
		m_Player.UpdateStats ();
	}

	private const int m_StartingPoints = 400;
	private const int m_StartingMinimum = 10;
	private int m_PointsLeft;

	// Player character
	private void CreateCharacter()
	{
		GameObject PlayerController = (GameObject)(Instantiate (m_PlayerPrefab, Vector3.one, Quaternion.identity));
		PlayerController.name = "Player";
		
		m_Player = PlayerController.GetComponent<PlayerCharacter> ();
		m_Player.Awake();
	}

	private void UpdateVitalitiesCurrentValues()
	{
		for (int i = 0; i < Enum.GetValues(typeof(VitalityType)).Length; ++i)
			m_Player.GetVitality(i).Current = m_Player.GetVitality(i).Total;
	}

	private PlayerCharacter m_Player;
	#endregion
}
