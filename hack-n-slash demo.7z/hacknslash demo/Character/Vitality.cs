﻿/// <summary>
/// Vitality stat.
/// August 19, 2015 
/// Max Zamana
/// 
/// Represents a set of player vitalities, such as health and mana.
/// </summary>

using System.Collections.Generic;

/// <summary> Vitality type. <para>   </para> You can add your own here, if you wish, but you will need to setup modifiers for them in Base Character class. </summary>
public enum VitalityType
{
	Health,
	Energy,
	Mana,
	Rage
}

public class Vitality : ModifiedStat
{
	#region public
	/// <summary> Initializes a new instance of the <see cref="Vitality"/> class. </summary>
	public Vitality()
	{
		SetupTranslation ();
		SetupStat ();
	}

	/// <summary> Gets or sets the current vitality stat value. </summary>
	/// <value>The current vitality stat value.</value>
	public int Current
	{
		get	{return m_Current;}
		set
		{
			m_Current = value;
			if (m_Current > Total)
				m_Current = Total;			
		}
	}

	/// <summary> Gets the translation of vitality type string, written as a parameter. </summary>
	/// <returns>The translation of parameter string.</returns>
	/// <param name="str">Parameter string.</param>
	public string GetTranslationOf (string str)
	{
		return m_Translation[str];
	}

	#endregion

	#region private
	/// <summary> Setups the translation dictionary. </summary>
	private void SetupTranslation()
	{
		m_Translation = new SortedDictionary<string, string> ();
		m_Translation.Add("Health", "Здоровье");
		m_Translation.Add("Energy", "Энергия");
		m_Translation.Add("Mana", "Мана");
		m_Translation.Add("Rage", "Ярость");
	}	

	/// <summary> Initializes current vitality stat. </summary>
	private void SetupStat()
	{
		m_Current = 0;
		ExperienceToNextLevel = 40;
		ExperienceToNextLevelModifier = 1.1f;
	}

	private static SortedDictionary<string, string> m_Translation;
	private int m_Current;
	#endregion
}
