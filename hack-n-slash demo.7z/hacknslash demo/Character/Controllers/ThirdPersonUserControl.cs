using System;
using UnityEngine;
using UnityStandardAssets.CrossPlatformInput;

namespace UnityStandardAssets.Characters.ThirdPerson
{
	[RequireComponent(typeof (Animator))]
    [RequireComponent(typeof (ThirdPersonCharacter))]
    public class ThirdPersonUserControl : MonoBehaviour
    {
		#region private
		private void Start()
		{            
			if (Camera.main != null)
				m_CameraTransform = Camera.main.transform;
			
			m_Character = GetComponent<ThirdPersonCharacter> ();
			m_Animator = GetComponent<Animator> ();
		}
		
		
		private void Update()
		{
			if (!m_Jump)            
				m_Jump = CrossPlatformInputManager.GetButtonDown("Jump");

			// FOR TEST PUPROSES ONLY !!!
			if (Input.GetKey (KeyCode.LeftShift)) 
			{
				AnimatorStateInfo CurrentState = m_Animator.GetCurrentAnimatorStateInfo(0);

				if (!CurrentState.IsName("Attack") && CrossPlatformInputManager.GetButton ("Fire1"))
					m_Attack = true;
				else
					m_Attack = false;

				m_Block = CrossPlatformInputManager.GetButton ("Fire2");
			}

		}
		
		private void FixedUpdate() // Fixed update is called in sync with physics
		{
			// do we need the character to crouch
			bool crouch = Input.GetKey(KeyCode.C);
			
			// move direction and force
			float h = CrossPlatformInputManager.GetAxis("Horizontal");
			float v = CrossPlatformInputManager.GetAxis("Vertical");
			if (m_CameraTransform != null) // calculate camera relative direction to move:
			{                
				m_CameraForward = Vector3.Scale(m_CameraTransform.forward, new Vector3(1, 0, 1)).normalized;
				m_MoveForce = 0.5f * (v*m_CameraForward + h*m_CameraTransform.right);
			}
			else // we use world-relative directions in the case of no main camera                
				m_MoveForce = 0.5f * (v*Vector3.forward + h*Vector3.right); 

			if (Input.GetKey(KeyCode.LeftShift)) // walk speed multiplier
				m_MoveForce *= 2.0f;

			// pass all parameters to the character control script
			m_Character.Move(m_MoveForce, crouch, m_Jump, m_Attack, m_Block);
			m_Jump = false;	
		}


		private ThirdPersonCharacter m_Character; 
		private Animator m_Animator; 			  
		private Transform m_CameraTransform;      

		private Vector3 m_CameraForward;          
		private Vector3 m_MoveForce;			  

		private bool m_Jump;                      
		private bool m_Attack;
		private bool m_Block;
		#endregion          
    }
}
