﻿/// <summary>
/// Modifying attribute.
/// August 16, 2015
/// Max Zamana
/// 
/// Represents stat, that is modified by attributes (Total base value + Modifiers added value)
/// </summary>


using System.Collections.Generic;

/// <summary>
/// Modifying attribute struct. 
/// <para>   </para>
/// Represents attribute, that can affect ModifiedStat value.  
/// </summary>
public struct ModifyingAttribute
{
	/// <summary>
	/// Initializes a new instance of the <see cref="ModifyingAttribute"/> struct.
	/// </summary>
	/// <param name="attr">Attribute to modify our modified stat.</param>
	/// <param name="rat">Ratio, at which it will modify stat.</param>
	public ModifyingAttribute (Attribute attr, float rat)
	{
		attribute = attr;
		ratio = rat;
	}

	public Attribute attribute;
	public float ratio;
}

public class ModifiedStat : BaseStat 
{
	#region public
	/// <summary>
	/// Initializes a new instance of the <see cref="ModifiedStat"/> class.
	/// </summary>
	public ModifiedStat()
	{
		m_Modifications = new List<ModifyingAttribute>();
		m_AddedValue = 0;
	}

	/// <summary>
	/// Adds the modifying attribute to this stat.
	/// </summary>
	/// <param name="modifier">Modifying attribute.</param>
	public void AddModifier(ModifyingAttribute modifier)
	{
		m_Modifications.Add(modifier);
	}

	/// <summary>
	/// Gets the adjusted modified value of stat (base + buff - debuff + added).
	/// </summary>
	/// <value>Total modified value of stat.</value>
	new public int Total // polymorphic override
	{
		get {return Base + Buff - Debuff + m_AddedValue;}
	}

	/// <summary>
	/// Updates current added value, based on this stats modifiers.
	/// </summary>
	public void Update()
	{
		CalculateModifierValue ();
	}

	/// <summary>
	/// Helping function, that return a string to serialize modifiers with their ratio values.
	/// <para>   </para>
	/// In default mode you don't need to use it, but if you want your modifiers to be different
	/// for each kind of attribute, skill, stat, you will need to save this string to savegame
	/// and after loading parse it to get values you need.
	/// </summary>
	/// <returns>The modifiers as string.</returns>
	public string GetModifiersAsString()
	{
		string Result = "";
		string Delimeter = "";
		foreach (ModifyingAttribute Modification in m_Modifications) 
		{
			if (m_Modifications.IndexOf(Modification) != m_Modifications.Count - 1) // not the last one mod
				Delimeter = " ";

			Result += Modification.attribute.Name + "_" + Modification.ratio.ToString () + Delimeter;
		}

		UnityEngine.Debug.Log (Result);

		return Result;
	}
	#endregion

	#region private
	/// <summary>
	/// Calculates modifiers added value.
	/// </summary>
	private void CalculateModifierValue()
	{
		m_AddedValue = 0;
		if (m_Modifications.Count != 0) 
		{
			foreach (ModifyingAttribute mod in m_Modifications)
			{
				m_AddedValue += (int)(mod.attribute.Total * mod.ratio);
			}
		}
	}

	// List of modifications and total value added by them to this stat
	private List<ModifyingAttribute> m_Modifications;
	private int m_AddedValue;
	#endregion
}
