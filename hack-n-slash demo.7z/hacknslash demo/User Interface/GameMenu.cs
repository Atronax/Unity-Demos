﻿using UnityEngine;
using System.Collections;

public class GameMenu : MonoBehaviour {

	// Use this for initialization
	void Start () 
	{
		InitializeWidgetsSizes();
		InitializeVisibility();
	}
	
	// Update is called once per frame
	void Update () 
	{
		if (Input.GetKeyUp (KeyCode.Escape))
			m_IsVisible = !m_IsVisible;
	}

	void OnGUI ()
	{
		if (m_IsVisible) 
		{
			// setup the skin
			GUI.skin = m_GamemenuSkin;

			// display widgets
			DisplayBackground ();
			DisplaySaveButton ();
			DisplayLoadButton ();
		}
	}

	#region public
	public GUISkin m_GamemenuSkin;
	#endregion

	#region private
	private void InitializeWidgetsSizes()
	{
		Offset = 10;
		
		// SmallBlockWidth = 30;
		PreMediumBlockWidth = 100;
		MediumBlockWidth = 150;
		// LargeBlockWidth = 250;
		
		BlockHeight = 25;
		BlockInterval = 1;

		MenuWidth = 400;
		MenuHeight = 500;

		MenuPositionX = (int)((Screen.width - MenuWidth) / 2.0f);
		MenuPositionY = (int)((Screen.height - MenuHeight) / 2.0f);
	}

	// private int SmallBlockWidth, LargeBlockWidth;
	private int PreMediumBlockWidth, MediumBlockWidth;
	private int BlockHeight, BlockInterval;
	private int Offset;

	private int MenuPositionX, MenuPositionY;
	private int MenuWidth, MenuHeight;

	// Display GUI
	private void DisplayBackground()
	{
		GUI.Box (new Rect (MenuPositionX, MenuPositionY, MenuWidth, MenuHeight), "Меню");
	}

	private void DisplaySaveButton()
	{
		m_SaveFilename = GUI.TextField (new Rect (MenuPositionX + Offset + PreMediumBlockWidth + Offset, MenuPositionY + Offset, MediumBlockWidth, BlockHeight), m_SaveFilename);
		bool SaveIsPressed = GUI.Button (new Rect (MenuPositionX + Offset, MenuPositionY + Offset, PreMediumBlockWidth, BlockHeight), "Сохранить");

		if (SaveIsPressed && m_SaveFilename != "") 
		{
			GameSettings GameSettings = GameObject.Find("Settings").GetComponent<GameSettings>();
			GameSettings.CurrentSaveFilename = m_SaveFilename;

			Debug.Log("in DisplaySaveButton");
			GameSettings.SaveCharacterData();
		}
	}

	private void DisplayLoadButton()
	{
		m_SaveFilename = GUI.TextField (new Rect (MenuPositionX + Offset + PreMediumBlockWidth + Offset, MenuPositionY + Offset + BlockHeight + BlockInterval, MediumBlockWidth, BlockHeight), m_SaveFilename);
		bool LoadIsPressed = GUI.Button (new Rect (MenuPositionX + Offset, MenuPositionY + Offset + BlockHeight + BlockInterval, PreMediumBlockWidth, BlockHeight), "Загрузить");

		if (LoadIsPressed && m_SaveFilename != "") 
		{
			GameSettings GameSettings = GameObject.Find("Settings").GetComponent<GameSettings>();
			GameSettings.CurrentSaveFilename = m_SaveFilename;
			GameSettings.LoadCharacterData();
		}
	}

	// saving and loading
	string m_SaveFilename = "";

	// visibility
	private void InitializeVisibility()
	{
		m_IsVisible = false;
	}

	private bool m_IsVisible;
	#endregion
}
