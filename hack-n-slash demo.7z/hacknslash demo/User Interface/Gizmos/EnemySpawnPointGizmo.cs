﻿using UnityEngine;

public class EnemySpawnPointGizmo : MonoBehaviour 
{
	#region public
	public void OnDrawGizmos()
	{
		Gizmos.DrawIcon (transform.position, "princhenka.png");
	}
	#endregion
}
