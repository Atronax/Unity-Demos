﻿using UnityEngine;

public class PlayerSpawnPointGizmo : MonoBehaviour 
{
	#region public
	public void OnDrawGizmos()
	{
		Gizmos.DrawIcon (transform.position, "elephant.png");
	}
	#endregion
}
